# Kapture Wiki – SPFx prototype v0.1.1

Upgrade to the existing Kapture Wiki SharePoint application. The solution ID and web-part component ID are intentionally preserved; the solution version is incremented to 0.1.1.0 so the package can be deployed as an update, not as a second app.

## Features
- Lists documents in `/sites/Kapture/Shared Documents/TEST Kapture Wiki Folder`.
- Searches filenames in the configured folder.
- Opens the original SharePoint documents.
- Uploads files directly into that same SharePoint folder using the signed-in user's SharePoint permissions.
- Displays the supplied Indovance logo.
- Does not expose the test-folder path in the user interface.

## Upload constraints
- Prototype limit: 10 MB per file.
- Uploads require the signed-in user to have permission to add files to the target SharePoint folder.
- Files are stored in SharePoint; no separate database or storage service is used.
- This prototype does not implement chunked uploads, file-type restrictions, metadata editing, or full-text indexing.

## Build
Use the existing GitHub Actions build workflow. After dependencies are installed, run:
`npx gulp clean`
`npx gulp bundle --ship`
`npx gulp package-solution --ship`

Output: `sharepoint/solution/kapture-wiki.sppkg`

## Deployment
Upload the generated `.sppkg` to the tenant App Catalog as an upgrade to the existing Kapture Wiki application. Keep the existing app/solution identity. Do not install as a separately named second app.
