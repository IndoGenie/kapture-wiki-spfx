# Kapture Wiki SPFx build repository

This repository builds a SharePoint Framework package for the Kapture Wiki prototype.

## GitHub setup
1. Keep `Kapture-Wiki-SPFx-Source.zip` in the repository root.
2. Keep `.github/workflows/build.yml` at that exact path.
3. Commit both files to the `main` branch.
4. Open **Actions** → **Build Kapture Wiki SPFx Package**.
5. Open the latest run. If it succeeds, open **Artifacts** and download `Kapture-Wiki-SharePoint-Package`.
6. The downloaded artifact contains `kapture-wiki.sppkg`, which is the file for the SharePoint App Catalog.

## Important
- The source ZIP is not the deployable package. GitHub Actions must successfully build it first.
- This build uses SPFx 1.20.0 runtime packages and 1.20.2 build tooling, with Node.js 18.19.0.
- `@microsoft/sp-webpart-workbench` is deliberately excluded: the local workbench package is historical and was removed from current SPFx projects.
- `@microsoft/sp-tsconfig` is excluded; TypeScript configuration extends the Rush Stack compiler configuration.
- This is still a prototype. The build must pass before deployment, and the SharePoint test folder path/permissions must be validated in the tenant.
