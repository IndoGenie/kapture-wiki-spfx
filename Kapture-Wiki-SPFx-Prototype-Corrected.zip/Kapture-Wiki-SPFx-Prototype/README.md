# Kapture Wiki – SPFx prototype v0.1.2

This is an update to the existing Kapture Wiki SharePoint application. The SharePoint solution ID and web-part component ID are preserved, and the solution version is incremented to `0.1.2.0` so the package is intended to update the existing app rather than create a second app.

## Included changes
- Restores the complete, valid `KaptureWiki.tsx` component (the supplied ZIP contained only a fragment of this file, which caused the TypeScript syntax errors).
- Keeps document listing, filename search, and links to the original SharePoint files.
- Adds an Upload document control that writes to `/sites/Kapture/Shared Documents/TEST Kapture Wiki Folder`.
- Embeds the supplied Indovance logo in the component.
- Removes the visible test-folder location message.
- Keeps the existing application identity and web-part identity.

## Upload behaviour and limits
- There is no hard-coded 10 MB limit in this prototype.
- Uploads use a single SharePoint REST request. The effective maximum is still subject to SharePoint tenant/library limits and request constraints; this is not a chunked large-file uploader.
- The signed-in user must have permission to add files to the target SharePoint folder.
- Files are stored in SharePoint; no separate database or storage service is used.

## Build
Use the existing GitHub Actions workflow. After dependencies are installed, run:
`npx gulp clean`
`npx gulp bundle --ship`
`npx gulp package-solution --ship`

Expected output: `sharepoint/solution/kapture-wiki.sppkg`

## Deployment
Upload the generated `.sppkg` as an upgrade to the existing Kapture Wiki application in the App Catalog. Keep the existing app/solution identity; do not create a second app with a different identity.
