import * as React from 'react';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IKaptureWikiProps, IWikiFile } from './IKaptureWikiProps';
import styles from './KaptureWiki.module.scss';

interface IState { files: IWikiFile[]; query: string; loading: boolean; error: string; }

export default class KaptureWiki extends React.Component<IKaptureWikiProps, IState> {
  public constructor(props: IKaptureWikiProps) {
    super(props);
    this.state = { files: [], query: '', loading: true, error: '' };
  }
  public componentDidMount(): void { this.loadFiles(); }
  private async loadFiles(): Promise<void> {
    this.setState({ loading: true, error: '' });
    const folder = this.props.folderServerRelativeUrl.replace(/'/g, "''");
    const endpoint = `${this.props.siteUrl}/_api/web/GetFolderByServerRelativePath(decodedurl='${folder}')/Files?$select=Name,ServerRelativeUrl,TimeLastModified,Length&$orderby=TimeLastModified desc`;
    try {
      const response: SPHttpClientResponse = await this.props.spHttpClient.get(endpoint, SPHttpClient.configurations.v1, { headers: { 'Accept': 'application/json;odata=nometadata' } });
      if (!response.ok) { throw new Error(`SharePoint returned ${response.status}. Check folder path and your access permissions.`); }
      const data = await response.json();
      this.setState({ files: data.value || [], loading: false });
    } catch (e) { this.setState({ loading: false, error: e && e.message ? e.message : 'Unable to load documents from SharePoint.' }); }
  }
  private get filteredFiles(): IWikiFile[] {
    const q = this.state.query.trim().toLowerCase();
    return q ? this.state.files.filter(f => f.Name.toLowerCase().indexOf(q) >= 0) : this.state.files;
  }
  private iconFor(name: string): string {
    const ext = (name.split('.').pop() || '').toLowerCase();
    if (ext === 'pdf') return 'PDF'; if (['doc','docx','odt'].indexOf(ext) >= 0) return 'DOC';
    if (['xls','xlsx','csv','ods'].indexOf(ext) >= 0) return 'XLS'; if (['ppt','pptx','odp'].indexOf(ext) >= 0) return 'PPT'; return 'FILE';
  }
  public render(): React.ReactElement<IKaptureWikiProps> {
    return <div className={styles.kaptureWiki}>
      <header className={styles.header}>
        <div className={styles.brand}><div className={styles.logo}>K</div><div><div className={styles.brandName}>Kapture Wiki</div><div className={styles.brandSub}>INDOVANCE KNOWLEDGE HUB</div></div></div>
        <div className={styles.user}>Signed in as <strong>{this.props.displayName}</strong></div>
      </header>
      <section className={styles.hero}>
        <div className={styles.eyebrow}>KNOWLEDGE, CONNECTED</div>
        <h1>Your knowledge.<br/><span>One place.</span></h1>
        <p>Find the documents and information you need across Kapture.</p>
        <div className={styles.search}><span>⌕</span><input aria-label="Search documents" placeholder="Search documents by name..." value={this.state.query} onChange={e => this.setState({ query: e.currentTarget.value })}/><button onClick={() => this.setState({ query: '' })}>Clear</button></div>
      </section>
      <main className={styles.content}>
        <div className={styles.sectionHeading}><div><div className={styles.eyebrow}>SHAREPOINT LIBRARY</div><h2>Documents</h2></div><button className={styles.refresh} onClick={() => this.loadFiles()}>↻ Refresh</button></div>
        <div className={styles.folderNote}>Connected test location: <strong>TEST Kapture Wiki Folder</strong></div>
        {this.state.loading && <div className={styles.status}>Loading files from SharePoint…</div>}
        {!!this.state.error && <div className={styles.error}><strong>Couldn't load the test folder.</strong><br/>{this.state.error}<br/><small>Confirm the folder path and that this page is running inside the Kapture SharePoint site.</small></div>}
        {!this.state.loading && !this.state.error && <>
          <div className={styles.resultCount}>{this.filteredFiles.length} document{this.filteredFiles.length === 1 ? '' : 's'} {this.state.query ? 'found' : 'available'}</div>
          {this.filteredFiles.length ? <div className={styles.fileGrid}>{this.filteredFiles.map(file => <a className={styles.fileCard} href={`https://teknovance.sharepoint.com${file.ServerRelativeUrl}`} target="_blank" rel="noreferrer" key={file.ServerRelativeUrl}><div className={styles.fileIcon}>{this.iconFor(file.Name)}</div><div className={styles.fileInfo}><div className={styles.fileName}>{file.Name}</div><div className={styles.fileMeta}>{file.Length ? `${Math.max(1, Math.round(Number(file.Length) / 1024))} KB` : 'SharePoint document'} · {new Date(file.TimeLastModified).toLocaleDateString()}</div></div><div className={styles.open}>↗</div></a>)}</div> : <div className={styles.empty}>No matching documents. Try another search term.</div>}
        </>}
      </main>
      <footer className={styles.footer}>Kapture Wiki · Prototype · Documents remain stored in SharePoint</footer>
    </div>;
  }
}
