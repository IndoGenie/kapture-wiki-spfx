# Kapture Wiki — SPFx Prototype (source package)

This is the first SPFx implementation scaffold for the Kapture Wiki prototype. It is configured for SharePoint Framework **1.20.0** as a provisional baseline; Ajit must confirm tenant compatibility before deployment.

## What it does
- Renders a branded Kapture Wiki home experience as a SharePoint client-side web part.
- Reads files in the configured SharePoint folder using the current signed-in user's SharePoint context (`SPHttpClient`).
- Provides client-side filename search and opens the original SharePoint files.
- Does not copy files, create a separate database, request app-only permissions, or change existing Kapture content.

Default test folder:
`/sites/Kapture/Shared Documents/TEST Kapture Wiki Folder`

## Important deployment note
**This ZIP is source code, not yet a deployable `.sppkg`.** The SPFx toolchain and its Microsoft packages must be installed and the project compiled to generate a valid `.sppkg`. This environment could not reach the npm registry to install the SPFx build dependencies, so no genuine `.sppkg` has been generated. Do not upload this ZIP or rename it to `.sppkg`.

## Build on a development machine
1. Install Node.js 18.17.1 (18.x) and npm. SPFx 1.20.0 is the provisional baseline; confirm compatibility with your tenant first.
2. Extract this ZIP.
3. Run `npm install` in the project directory.
4. Run `npx gulp clean`.
5. Run `npx gulp bundle --ship`.
6. Run `npx gulp package-solution --ship`.
7. The output should be `sharepoint/solution/kapture-wiki.sppkg`.
8. Have Ajit review the package and deploy it through the tenant App Catalog, then add the web part to a Kapture page.

## Folder configuration
The default folder is in `src/webparts/kaptureWiki/KaptureWikiWebPart.manifest.json` and can also be changed through the web part properties in a subsequent iteration. The web part uses SharePoint REST `GetFolderByServerRelativePath` and the signed-in user's delegated context.

## Permissions and testing
- The deploying user and test users need read permission to the test folder.
- SharePoint permissions remain authoritative; the web part does not bypass them.
- Test with a user who has no access to the folder to confirm that no files are returned.
- Validate the exact tenant-supported SPFx version, App Catalog availability, and deployment approval with the SharePoint administrator before building/releasing.

## Prototype limitations
- Search is limited to filenames in the configured test folder, not full document contents or the entire Kapture library.
- Upload, metadata editing, department taxonomy, and full-text indexing are intentionally not included in this first build.
- ODT and Office files open through their original SharePoint file links; preview rendering depends on Microsoft 365/browser support.


## Build corrections
- Removed an unused SPHttpClient import from the web part entry point.
- Made file-extension detection safe when a filename has no extension.
- Explicitly included webpack-env type definitions for the generated SCSS module typing.
