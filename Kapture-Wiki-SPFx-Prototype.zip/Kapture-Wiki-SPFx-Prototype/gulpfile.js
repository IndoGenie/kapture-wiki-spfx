'use strict';
const build = require('@microsoft/sp-build-web');

// Extracted article markup uses global camelCase classes; the SCSS declares
// those classes with :global(...) so SPFx CSS modules can style them safely.
build.initialize(require('gulp'));
