'use strict';
const build = require('@microsoft/sp-build-web');

// Suppress the known SPFx Sass CSS-module naming warnings. These warnings are
// emitted by the Sass task and otherwise cause the SPFx build rig to fail.
build.addSuppression(/Warning - \\[sass\\] The local CSS class 'wiki-(?:table-wrap|page|sheet|slide)' is not camelCase and will not be type-safe\\./);

build.initialize(require('gulp'));
