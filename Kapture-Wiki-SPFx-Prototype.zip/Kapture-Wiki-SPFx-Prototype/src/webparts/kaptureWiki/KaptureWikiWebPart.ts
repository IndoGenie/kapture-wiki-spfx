import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import * as React from 'react';
import * as ReactDom from 'react-dom';
import KaptureWiki from './components/KaptureWiki';
import { IKaptureWikiProps } from './components/IKaptureWikiProps';

export interface IKaptureWikiWebPartProps { description: string; testFolderServerRelativeUrl: string; }

export default class KaptureWikiWebPart extends BaseClientSideWebPart<IKaptureWikiWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IKaptureWikiProps> = React.createElement(KaptureWiki, {
      siteUrl: this.context.pageContext.web.absoluteUrl,
      folderServerRelativeUrl: this.properties.testFolderServerRelativeUrl || '/sites/Kapture/Shared Documents/TEST Kapture Wiki Folder',
      spHttpClient: this.context.spHttpClient,
      displayName: this.context.pageContext.user.displayName || 'Kapture user'
    });
    ReactDom.render(element, this.domElement);
  }
  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse('1.0'); }
  protected getPropertyPaneConfiguration() {
    return { pages: [{ header: { description: 'Kapture Wiki settings' }, groups: [{ groupName: 'SharePoint test folder', groupFields: [] }] }] };
  }
}
