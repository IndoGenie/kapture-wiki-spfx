import * as React from 'react';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IKaptureWikiProps, IWikiFile } from './IKaptureWikiProps';
import styles from './KaptureWiki.module.scss';

// Supplied Indovance logo embedded in this file to keep the SPFx package self-contained.
const INDOVANCE_LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYCAYAAAC+ZpjcAAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4nO3dzXXcWLIg4HhjAR3IMykLJrHCslMWPJYFTVlQlAWkLCjJArEtaI0FYi9zBT4LmOfAAXows8BVlapKP2QmgHtx8X3n1OnuBaXobgIIxA1ERAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMD6/FfuAIC8+qa9iIhd7jgq87DpDk+5gwDykWDBSvRNu40hkdpFxD8iYpv+YTrH9M9/IuIhhsTrmDEeYCYSLKhY37SXEfHfEbEPyVQpjhFxHxH/d9MdPuUNBZiKBAsq0zftPiL+GRGXEXGRNxp+4ikiPkXEvzbd4T5zLMCIJFhQgdRHdRkRN6FStVTHiHgXEZ/0b8HySbBgwVJidR0Rv4ZqVS2eIuJDRLyXaMFySbBgofqmvQoVq5o9RcTbTXe4yx0I8HISLFiYvml3EfFbDI3r1O8+hkTrIXcgwPP9r9wBAM/XN+1tRHQhuVqTfUR06f97YCFUsGAB0gyrjyGxWruHiPjFLC0onwQLCpfGLvw7NLEzeIohybrPHQjwfY4IoWCpkf1zSK74w0VEfE6/G0ChJFhQqNRz8zF3HBTro74sKJcjQihQ37QfI+Iqdxwswt2mO7zJHQTwZxIsKIzkihNIsqAwjgihIKmv5ipzGCzPlZ4sKIsKFhSib9rLGL4WhFO9MfkdyiDBggKk6ey+FuRcTxHx2tR3yE+CBZmlhc2fI2KXOxaqcIyIxqJoyEsPFuT3W0iuGM82ht8pICMVLMhI3xUT+mXTHT7lDgLWSoIFmaSjwcfQd8U0niLilaNCyMMRIeRzE5IrpnMRw+8YkIEKFmSQvhrscsfBKjS+KoT5qWBBHpqQmYt9lpCBBAtm1jftdUTsc8fBauzS7xwwI0eEMCON7WSi4R1mpoIF8/otJFfM7yIcS8OsVLBgJn3T7mOY2A65vN50h/vcQcAaqGDBfFQQyE3DO8xEggUz6Jv2NqzDIb9t+l0EJuaIECbWN+02hplXeq8owVMMs7GOuQOBmqlgwfQ0tlMSDe8wAxUsmJDGdgpmGTRMSIIFE0kzr7qI2GYOBb7lGMNRodlYMAFHhDCd65BcUa5tDL+jwARUsGACqbH9MXcc8AyvNLzD+FSwYBrmDbEUfldhAhIsGFnftJdhmTPLse+b9ip3EFAbR4QwIsucWSjLoGFkKlgwrpuQXLE8FzH87gIjUcGCkfRNu4thLAMsVbPpDg+5g4AaqGDBeEzHZuk0vMNIJFgwgr5pr0NjO8u3S7/LwJkcEcKZNLZTGQ3vMAIVLDifZc7UxDJoGIEKFpzBMmcq9nrTHe5zBwFLpYIF5/GmT638bsMZJFhwor5pbyNilzsOmMgu/Y4DJ3BECCdIy5y70HtF3Z5imI11zB0ILI0KFpxGYztroOEdTqSCBS+ksZ0V0vAOLyTBghdIM6+6iNhmDgXmdIzhqNBsLHgmR4TwMtchuWJ9tjH87gPPpIIFz5Qa2x9zxwEZvdLwDs+jggXPZxEua+cagGeSYMEz9E17GZY5wz5dC8BPOCKEn7DMGf7EMmh4BhUs+LmbkFzBFxcxXBPAD6hgwQ/0TbuLYSwD8GfNpjs85A4CSqWCBT9mijV8m2sDfkCCBd/RN+11aGyH79mnawT4BkeE8A0a2+FZNLzDd6hgwbdZ5gw/Zxk0fIcKFvyFZc7wYpZBw1+oYMHfeSOHl3HNwF9IsOArqWl3lzsOWJhd37S3uYOAkjgihCQtc+5C7xWc4imG2VjH3IFACVSw4A8a2+F0Gt7hKypYEBrbYUQa3iFUsOCLj7kDgEp8THPkYNUkWKxeas7dZg4DarGNCBPeWT1HhKxaamx/zB0HVOiVhnfWTAWLtXM0CNNwbbFqEixWq2/ay7DMGaayT9cYrJIjQlYpNeF2ofcKpmQZNKulgsVa3YTkCqZ2EcO1BqujgsXq9E27i6F6Bcyj2XSHh9xBwJxUsFgj06ZhXq45VkeCxar0TXsVGtthbvu0SB1WwxEhq5Ea2x/DvkHIQcM7q6KCxZpY5gz5WAbNqqhgsQqWOUMxLINmFVSwWAtvzlAG1yKrIMGieqm5dpc7DiAiInZpwTpUzREhVUvLnLvQewUleYphNtYxdyAwFRUsaqexHcqj4Z3qqWBRLY3tUDwN71RLBYuafcwdAPBDH9N8OqiOBIsqpSbabeYwgB/bRoQJ71TJESHVSY3tj7njAJ7tlYZ3aqOCRY0cDcKyuGapjgSLqvRNexmWOcPS7NO1C9VwREg1UrNsF3qvYImOMczGsgyaKqhgUZObkFzBUm1juIahCipYVKFv2l0M1Stg2ZpNd3jIHQScSwWLWpgKDXVwLVMFCRaL1zftVWhsh1rs0zUNi+aIkEVLje2PYd8g1OQphtlYGt5ZLBUsls4yZ6iPZdAsngoWi2WZM1TPMmgWSwWLJfOGC3VzjbNYEiwWqW/a64jY5Y4DmNQuXeuwOI4IWZy0zLkLvVewBk8xzMY65g4EXkIFiyXS2A7roeGdRVLBYlE0tsNqaXhnUVSwWJqPuQMAsnDtsygSLBajb9rbsMwZ1mqb7gGwCI4IWYTU2P6YOw4gu1ca3lkCFSyWwvEAEOFewEJIsChe37SXYZkzMNinewIUzREhRUvLnLvQewX84RjDbCzLoCmWChaluwnJFfBn2xjuDVAsFSyK1TftLobqFcC3NJvu8JA7CPgWFSxKZnoz8CPuERRLgkWR+qa9Co3twI/t070CiuOIkOKkxvbHsG8Q+LmnGGZjaXinKCpYlOgmJFfA81gGTZFUsCiKZc7AiSyDpigqWJTGmyhwCvcOiiLBohh9015HxC53HMAi7dI9BIrgiJAiaGwHRvAUw2ysY+5AQAWLUnwMyRVwHg3vFEMFi+w0tgMj0/BOdipYlOBj7gCAqrinkJ0Ei6z6pr0Ny5yBcW3TvQWycURINn3TbmNY5qz3CpjCKw3v5KKCRU4a24EpOSokGwkWWfRNexmWOQPT2qd7DczOESGzSzOvutB7BUzvGMNsLMugmZUKFjlch+QKmMc2hgXyMCsVLGbVN+0uhuoVwJyaTXd4yB0E66GCxdxMWQZycO9hVhIsZtM37VVobAfy2Kd7EMzCESGzsMwZKMBTDLOxNLwzORUs5nITkisgL8ugmY0KFpOzzBkojGXQTE4Fizl4YwRK4p7E5CRYTKpv2uuI2OWOA+Aru3Rvgsk4ImQyGtuBgml4Z1IqWEzJMmegVBdhGTQTUsFiEhrbgYXQ8M4kVLCYijdDYAncq5iEBIvR9U17G5Y5A8uwTfcsGJUjQkbVN+02hmXOeq+ApXiKYRn0MXcg1EMFi7FpbAeWRsM7o5NgMZq+aS/DMmdgmfbpHgajcETIKNLMqy70XgHLdYzhqNBsLM6mgsVYrkNyBSzbNoZ7GZxNBYuz9U27i6F6BVCDZtMdHnIHwbKpYDEGi1OBmrincTYJFmfpm/YqNLYDddmnexuczBEhJ7PMGaiYZdCcRQWLc9yE5Aqo00UM9zg4iQoWJ7HMGVgJy6A5iQoWp9IECqyBex0nkWDxYn3TXkfELnccADPYpXsevIgjQl5EYzuwQhreeTEVLF7KMmdgbSyD5sVUsHg2je3Ayml459lUsHgJb3DAmrkH8mwSLJ6lb9rbsMwZWLdtuhfCTzki5Kf6pt3GsMxZ7xWwdk8xLIM+5g6Esqlg8Rwa2wEGGt55FgkWP9Q37WVY5gzwtX26N8J3OSLku9LMqy70XgH81TGGo0KzsfgmFSx+5DokVwDfso3hHgnfpILFN6XG9sfccQAUrtl0h4fcQVAeFSy+RxMnwM9ZBs03SbD4m75pr0JjO8Bz7NM9E/7EESF/YpkzwItZBs3fqGDxVzchuQJ4iYsY7p3wOxUsftc37S6GsQwAvJxl0PxOBYuvaWwHOJ2Gd34nwSIiIvqmvY6IXe44ABZsl+6l4IgQje0AI9LwTkSoYDH4LSRXAGOwDJqIUMFavb5p9xHxOXccAJXR8L5yKlh40wIYn3vrykmwVqxv2tuwzBlgCtt0j2WlHBGuVFrm3IXeK4CpPMWwDPqYOxDmp4K1XhrbAaal4X3FJFgr1DftZURc5o4DYAX26Z7LyjgiXJk086oLvVcAcznGcFRoNtaKqGCtz3VIrgDmtI3h3suKqGCtSGpsf8wdB8BKvdLwvh4qWOui2RIgH/fgFZFgrUTftFcRsc8cBsCa7dO9mBVwRLgCljkDFMMy6JVQwVqHm5BcAZTgIoZ7MpVTwapc37S7GMYyAFCOZtMdHnIHwXRUsOqnqRKgPO7NlZNgVaxv2uuI2OWOA4C/2aV7NJVyRFgpje0AxdPwXjEVrHpZ5gxQtosY7tVUSAWrQn3T7iPic+44AHiW15vucJ87CMalglUnzZMAy+GeXSEJVmX6pr0Ny5wBlmSb7t1UxBFhRdIy5y70XgEszVMMs7GOuQNhHCpYddHYDrBMGt4rI8GqRN+0lxFxmTsOAE52me7lVMARYQXSzKsu9F4BLN0xhqNCs7EWTgWrDtchuQKowTaGezoLp4K1cKmx/TF3HACM6pWG92VTwVo+81MA6uPevnASrAXrm/YqIvaZwwBgfPt0j2ehHBEulGXOANWzDHrBVLCW6yYkVwA1u4jhXs8CqWAtUN+0uxjGMgBQv2bTHR5yB8HLqGAtk+ZHgPVwz18gCdbC9E17HRG73HEAMJtduvezII4IF0RjO8BqaXhfGBWsZbHMGWCdLINeGBWsheibdh8Rn3PHAUBWrzfd4T53EPycCtZyaHIEwLNgISRYC9A37W1Y5gxAxDY9EyicI8LCpWXOXei9AmDwFMNsrGPuQPg+FazyaWwH4Gsa3hdABatgGtsB+IFfNt3hU+4g+DYJVqHSzKsu9F4B8G3HGI4KzcYqkCPCcl2H5AqA79vG8KygQCpYBUqN7Y+54wBgEV5peC+PClaZzDkB4Lk8MwokwSpM37SXEbHPHQcAi7Hvm/YqdxD8mSPCgljmDMCJLIMujApWWW5CcgXAy13E8AyhECpYheibdhfDWAYAOFWz6Q4PuYNABaskpvICcC4N74WQYBWgb9rr0NgOwPl26ZlCZo4IM9PYDsDINLwXQAUrP8ucARiTZdAFUMHKyDJnACb0etMd7nMHsVYqWHl5wwBgKp4xGUmwMumb9jYidrnjAKBau/SsIQNHhBmkZc5d6L2Crx0j4iEi/if9+2NExPeOONJ1tE3/cR8R/zv95/1UAcICPcUwG+uYO5C1kWBl0DftvyPiMncckNkxIj5FxH8i4n7ML55Sf+M+Iv4REi74tOkOv+QOYm0kWDPT2M7KHSPiQww3/OMcf2EahXIZEf8dXmxYLw3vM5NgzSjd6Lv441gD1uIuIv6V+wafjhWvIuLXcETPuhxjOCo0G2smmtzndR2SK9blLoaBh29yJ1cREZvucNx0h9uIeBURbyL1ecEKbGN4BjETFayZpDfnx9xxwEzuIuLdEhpr01dWKlqsxaslXJc1UMGajwWcrMFDDL0eb5ZyE/+qonWXNxKYhWfRTFSwZtA37WVE/Dt3HDCxdylZWaz0EcrHcJRP3X7ZdIdPuYOonQRrYpY5swIPEfFm0x0ecgcyhnTNfgxfHFIvy6Bn4IhwejchuaJen2I4EqwiuYqI2HSHpzQz6G3uWGAiFzE8m5iQCtaE+qbdxTCWAWq0+CPBn0lHhv8OL0nUqanp5ag0KljTsmiTWr2pPbmK+H1Nz+sYjlSgNp5RE5JgTaRv2uuwooM6vdl0h7vcQcwlveFLsqjRPj2rmIAjwglobKdiq0quvpaO/D+H65q6aHifiArWNH4LN2Hqs9rkKkIli2pdhKPCSahgjcwyZyr1ftMdfFUXPl6hWpZBj0wFa3zeBKjNJ8nVH1Il603uOGBknl0jk2CNKO002+WOA0Z0DMnE36Sj0rvMYcCYdukZxkgkWCNJy5x/zR0HjOwXza/f9TaGKfZQi1/Ts4wRSLDGo7Gd2rwzhPD7UuKpukdNNLyPSJP7CDS2U6GHTXdocgexBOlYxdoRaqLhfQQqWGf6ajEs1ERT+/O9j6FXDWrxMT3bOIME63zXEbHNHQSM6M7b6/Olo0IJKTXZxvBs4wyOCM+QmgEfc8cBI3qKYQHsMXcgS9M37eewHou6vHIvOJ0K1nkcDVKbD26oJ1PFojaecWeQYJ2ob9rL8LZKXY4x9BNxgvTF5V3uOGBE+/Ss4wQSrBNobKdS78y8OtvbsKuQumh4P5EE6zQ3YeYVdblf8yLnsaQE9UPuOGBEF2EMyUk0ub+QRa9UytybEfVN+xi+LqYujcHDL6OC9XKm3FIbYxnGp+Gd2nj2vZAE6wX6pr0Oje3U5Ski3uUOojab7vApIu5zxwEj2qdnIM8kwXqm1OTnHJraGMswHXsKqc2Nhvfnk2A9n2XO1OYYxjJMJiWu/velJpZBv4AE6xnSMuerzGHA2IxlmN67MLaBulylZyI/IcF6Hhk7tTGWYQYpgdXjRm08E59BgvUTqalvlzsOGJmH/kw23eF9DMexUItd37S3uYMonQTrB9IyZ43t1MZYhvlpeKc2v6ZnJN8hwfoxje3UxpFVBimh/ZQ7DhiRhvefkGB9R2ris+SS2hjLkI/ho9TmUsP790mwvs8yZ2pzDGMDskmJreohtbEM+jskWN+Qmve2mcOAsRnLkN/7MLaBumwjwoT3b7Ds+S9S095j7jhgZPeb7vA6dxBE9E17FSrk1OeV9oM/U8H6Ozc+auRoqhBp/thD7jhgZJ6dfyHB+krftJdhmTP1MZahPBreqc0+PUNJJFhJatLzySm1MZahQCnhvcscBoztNw3vf5Bg/eEmNLZTH2MZymVPIbXZhuHcv5NgRUTftLvwFQT1OYaxDMVKie+H3HHAyK7TM3X1JFgDR4PUyFiG8tlTSI08U0OC9eWT6X3mMGBs9+lrNQqWEmA9ctRmn56tq7bqOVipGe8x7BukPq99ObgcfdN+Di961OUphtlYq62ir72CZZkzNTKWYXmMbaA2q/8yf7UJVlpQeZU5DBibI6cF2nSHhzC2gfpcrXkZ9GoTrFh5Zk21jGVYrrdhbAP1We2zdpUJVt+01xHhM1JqcwxjGRYr9aoY20BtdumZuzqra3JPy5y70HtFfd74cnD5+qZ9DEOPqctTRDRrq66vsYKlsZ0aGctQDw3v1GaVDe+rSrBSs51llNRIY3slNt3hU0Tc544DRna5tob3VSVYEfExdwAwAWMZ6vMmdwAwgVU9g1eTYPVNexv6GqiPsQwVSr0qPligNtv0LF6FVTS5p8b2x9xxwATebbrDbe4gGJ9NE1Ts1Roa3tdSwVpVWZLVOIYqR7XsKaRiq3gmV59g9U17GXZ8Uad3a97ztQab7vA+hkQaarJPz+aqVZ1gpRL76j4NZRWMZVgPDe/U6Lf0jK5W1QlWRNyExnbq5OhoJdIXop9yxwEj28bwjK5WtU3ufdPuYpjYDrW523QHVY0V8aEOFWvSsvPq1FzBcjRIjTQ+r1D64sr/79So2md1lQlW37RXobGdOn1Yw+fNfNP7GBJsqMk+PbOrU12CpbGdih3DWIbVSl+M2lNIjapseK8uwQrLnKmXsQwrl74crbJfhVWrsjBSVYKVFkleZQ4DpmAsA1+oYlGjq9qWQVeVYEWFGTAkHqpExO9jG+4yhwFTqOoZXk2C1TftdUTscscBE7ir9TNmTvYuNLxTn116llehigQrzYipemAZq6Wxmb9JX5J+yB0HTOAmPdMXr4oEKzS2U68PGtv5DnsKqVE1De+Ln+SemuI+544DJnDcdIdXuYOgXGl+0MfcccAEXqd+w8WqoYLl5kKtHA3yQ+nL0vvMYcAUFv9sX3SC1TftbVjmTJ3uN93Bgl+eQyJOjbbpGb9Yiz0itPyUylW7AJXx9U37McwApE6vlroebMkVrMWXD+E7jGXgpd6GsQ3UabHP+kUmWH3TXoZlztTJWAZeLH1pamwDNdqnZ/7iLO6IMC2E7ELvFXV6t+kOt7mDYJn6pn0M90bqc4yhbWJRVdolVrBuwg2EOh0lV5xJ9ZMabWOBw8QXlWD1TbuLiGrG6MNfeDhylvTl6X3uOGAC1ykHWIxFJVhRyXRX+AZjGRiLRJ1aLSoHWEyClSYW7zOHAVPxUGQU6QvU97njgAnsUy6wCItock+N7Y9h3yB1utt0hze5g6Ae7plU7CmG2VjFN7wvpYJlmTO1MpaB0aWHz7vcccAEFrMMuvgKlmXOVM5YBiZjbAMVK34Z9BIqWIvIVOEExjIwNUfP1Kr43KDoBKtv2uuIWNRnmfACjgaZVHrDv88cBkxhl3KEYhV7RKhJk8rdb7rD69xBUL++abcx3EuhNkU3vJdcwfoYkivqpXrFLDbd4Rga3qnTRRS8DLrIBCs1ti9yuSM8w12aVQRzeR/D2z7U5jLlDMUpMsGKgjNSOJOxDMwuHaH4vaNWReYMxSVYfdPehs+KqdeHUvsFqNumO9xFhMopNdqm3KEoRTW5p2bMLvReUafjpju8yh0E62WuIBV7iogm9RwWobQKlsZ2auaIhqzS2AZLxalRcQ3vxSRYfdNehmXO1Ot+0x082CjB29DwTp32KZcoQhEJVpp5VfxUVjiD6hVFSEcoH3LHARP5LeUU2RWRYEXEdWhsp17GMlCa9xFxzB0ETGAbQ06RXfYm975pdzE0tkONip40zHr1TXsVhfWswIia3C+2JVSwHA1SM2MZKFIa23CfOQyYSvbcImuCld6g9jljgAkdN93hNncQ8ANW6FCrfcoxssmWYGlsZwU0tlO0NLbhLnMYMJWsDe85K1g3YeYV9TKWgaUwtoFaXcSQa2SRJcFK04SL6PKHiahesQipR9DYBmp1nWsZdK4KlqNBamYsA4uSegWPmcOAqWTJOWZPsPqmvY6I3dx/L8zkKVSvWCa/t9Rql3KPWc06Bys1mz2G3ivq9c6XgyxV37Sfw5fd1Gn2mYRzV7Asc6ZmxjKwdKpY1Gr2ZdCzJVipyayYJYwwAQ8nFi31Dr7PHQdM5HLOhvc5K1hWMlAzYxmoxbswtoF6zZaLzJJg9U17G5Y5UzfVK6qQelRMeKdW25STTG7yJve+abcxLHPWe0Wt7jbd4U3uIGBMfdM+hhdj6vQUwzLo45R/yRwVLI3t1MxYBmrlpYFazdLwPmmC1TftZfjkl7p9mPOzX5hL2lN4nzkMmMo+5SiTmeyIMM286kKJmXodN93hVe4gYCqpxeMxdxwwkWMMR4WTvCRPWcG6DskVdXM0SNVSj4qGd2q1jQn3Ik9SweqbdhdD9Qpqdb/pDq9zBwFTs4GDFWim2B87VQXLMmdqp3rFKqTjE7/v1GySnGX0BKtv2qvQ2E7d7qZ424FSbbrDXUT4nadW+5S7jGrUBCuVklWvqJm3edbK7z01+y3lMKMZu4J1E87pqZuxDKxSGttgHRS1uoghhxnNaE3uPudlBYxlYNVs5mAFXo014X3MCtaomR8UyBEJq5YePB9yxwETGi2XGaWCpXrFChjLAGGINKswShVrrAqW6hW1U72C+H1sg+Gj1GyUnObsCpbqFStwt+kOFt/CV/qm/RxG8lCvs6tYY1Swrkb4M6BUxjLAt6liUbOrc/+AMRKsf47wZ0Cp3hnLAH+XxjbcZQ4DpnJ2bnNWgpV2Dm7PDQIKddx0h/e5g4CCvY2hygu12aYc52TnVrBUr6iZviv4gVTdNbaBWp2V45ybYF2e+fNQqvt0BAL8wKY73EbEMXMYMIWzcpyTE6z09eD2nL8cCqZ6Bc/nQxBqtE25zknOqWDtz/hZKNn7sVYlwBpsusOniLjPHQdMYH/qD56TYP3jjJ+FUhmiCKdRxaJGJ+c65yRYZ3XXQ6GMZYATbLrDQxjbQH22p/6gBAv+YCwDnMfYBmqzP/UHT0qwzmn6goJpbIcz2FNIjU7NeU6tYJ30l0HBjGWAEaQq8DF3HDCi7Sk/JMGCgeoVjMf1RE22p/yQBAuMZYBRpWrwfeYwYCzbU35ojGXPsGR6RmAaqlismgSLtTOWASaQqsK+ymW1JFismbEMMK13YWwDKyXBYs0cYcCEUnXYhHdWSYLFWhnLADPYdIe7iHjIHQfMTYLFWqlewXxUsVidUxMsZ+osmbEMMKNULf6UOw440Uk5z6kJlnIvS2UsA+ShisVSnZTzOCJkbYxlgAxS1djLDavxX6f+YN+0/2/MQGAGx013eJU7CFirvmkvIqIL20BYkE13OClXOqeCdTzjZyEHje2QUaoeq2KxJMdTf/CcBEsfFktiLAMUII1tuM8cBjzXybnOOQnW/5zxszA31SsohyoWS3FyrnNOgnV/xs/CnIxlgIKkavJd5jDgOe5P/cGTE6x0gfgai9Lp+YAy2VNI6Z7OaS05d0zDyX8xzMRYBihQqip/yB0H/MD9OT98boL1f8/8eZjScdMd3ucOAvi2TXe4DV+kU66zcpxzEyyrDyiZxnYonwnvlOqsHOesBCsdvdyd82fARIxlgAXYdIdPod2E8tyd214yxqqcf43wZ8DYVK9gOVSxKM3Zuc3ZCVaqEhzP/XNgRMYywIJsusNDOA2hHMcxTkDGWvbsM3hKYSwDLNPbMLaBMozyDBklwUqrD45j/FlwJmMZYIHsKaQQx5TTnG2sClaEC4P8jGWABUvX7zF3HKzaaLnMaAmWKhYF0NgOy+c6JpfRqlcR41awInwJQj7GMp04PVIAAAPQSURBVEAF0nV8nzkM1mnUHGbUBCvNMzF8lLk9hbdeqMmb0PDOvD6lHGY0Y1ewInwJwvzeGcsA9UjXs75e5vIUE5zAjZ5gpQvDUSFzudfYDvVJ1/V97jhYhbdTvKRPUcH60vB+N8WfDV9xNAh1c1TI1O7GbGz/2iQJVvI2Ih4m/PPhF0eDUK90ff+SOw6q9RATnrhNlmCloXHePpjKW18NQv3Sda7thLE9RcSbKQdT/9dUf/AXfdPuIuJzRFxM/XexGneb7uBoEFakb9qPEXGVOw6q8BQRr9MOzMlMeUQYEb8v8fT2wVgkV7BC6bq/yx0HVXg7dXIVMUMF64u+aa8i4uNcfx9VklzByqlkcaY3UzW1/9VsCVaEJIuzSK6AiJBkcbLZkquImROsCD1ZnOTdpjvc5g4CKEfftLcRcZM7DhZhlp6rv5q8B+uv0n/B12GEAz/35SuP29yBAGVJ9wVfqvMzD5EhuYrIUMH6om/aixiOCy9zxUDRHmJIriTiwHelU5GPEbHLHQvF+RQTj2L4kWwJ1hepL+u3cGTIH97HcCzozRT4qfTCfhMR17ljoQhPMXwpeJcziOwJVkRE37TbGN5A9nkjIbNjDG8b95njABaob9p9DM+Sbd5IyOhTTLRb8KWKSLC+6Jv2MoZq1jZzKMzrKSI+6LUCxpAa4H8NJyNrcowhsfqUO5AvikqwvkjHhjch0ardU0R8iIj3jgOBMaVjw+uQaNXuGENLyV3mOP6myATri5Ro/RqaF2tzjIh/hcQKmNhXidY/w0t7TR5iOPm4yx3I9xSdYH2RvhL5NYYvDr2JLNeniPhXSSVcYD1SG8o/w9frS/UUw3PkwxK+MF9EgvW1dIH8I4YLZJs3Gn7iy8Xwn4j4pFoFlCBVtb5+lnhxL9cx0nNkaS/ni0uwvpa+Ptylf/4Rw0XiODGPY/rnISL+JyLuS/iKA+Bn0inJLiL+T/rXbXiBz+Ehhhfz/6R//7Dk58iiE6wfSZ/rMr3jki8AgO9JL/HbzGFUz2geAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAqMf/B0KETNxABDi8AAAAAElFTkSuQmCC';

interface IKaptureWikiState {
  files: IWikiFile[];
  query: string;
  loading: boolean;
  uploading: boolean;
  error: string;
  uploadMessage: string;
}

export default class KaptureWiki extends React.Component<IKaptureWikiProps, IKaptureWikiState> {
  private fileInput: React.RefObject<HTMLInputElement>;

  public constructor(props: IKaptureWikiProps) {
    super(props);
    this.state = { files: [], query: '', loading: true, uploading: false, error: '', uploadMessage: '' };
    this.fileInput = React.createRef<HTMLInputElement>();
  }

  public componentDidMount(): void {
    this.loadFiles();
  }

  private async loadFiles(): Promise<void> {
    this.setState({ loading: true, error: '' });
    try {
      const folder = this.props.folderServerRelativeUrl.replace(/'/g, "''");
      const endpoint = `${this.props.siteUrl}/_api/web/GetFolderByServerRelativePath(decodedurl='${folder}')/Files?$select=Name,ServerRelativeUrl,TimeLastModified,Length&$orderby=TimeLastModified desc`;
      const response: SPHttpClientResponse = await this.props.spHttpClient.get(
        endpoint,
        SPHttpClient.configurations.v1,
        { headers: { Accept: 'application/json;odata=nometadata' } }
      );
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`SharePoint returned ${response.status}. ${detail.substring(0, 250)}`);
      }
      const data = await response.json();
      this.setState({ files: (data.value || []) as IWikiFile[], loading: false });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'An unexpected error occurred.';
      this.setState({ loading: false, error: message });
    }
  }

  private async uploadFile(file?: File): Promise<void> {
    if (!file) return;

    this.setState({ uploadMessage: '', error: '' });
    // No arbitrary 10 MB limit is imposed by this prototype. SharePoint's own
    // tenant/library limits and the user's permissions still apply.
    this.setState({ uploading: true, uploadMessage: `Uploading ${file.name}…` });

    try {
      const folder = this.props.folderServerRelativeUrl.replace(/'/g, "''");
      const fileName = file.name.replace(/'/g, "''");
      const endpoint = `${this.props.siteUrl}/_api/web/GetFolderByServerRelativePath(decodedurl='${folder}')/Files/AddUsingPath(decodedurl='${encodeURIComponent(fileName)}',overwrite=true)`;
      const buffer = await file.arrayBuffer();
      const response: SPHttpClientResponse = await this.props.spHttpClient.post(
        endpoint,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: 'application/json;odata=nometadata',
            'Content-Type': 'application/octet-stream'
          },
          body: buffer as unknown as string
        }
      );

      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`Upload failed (${response.status}). ${detail.substring(0, 250)}`);
      }

      this.setState({ uploading: false, uploadMessage: `${file.name} uploaded successfully.` });
      await this.loadFiles();
    } catch (error) {
      const message = error instanceof Error
        ? error.message
        : 'Upload failed. Confirm that you have permission to add files to this SharePoint folder.';
      this.setState({ uploading: false, uploadMessage: message });
    } finally {
      if (this.fileInput.current) this.fileInput.current.value = '';
    }
  }

  private get filteredFiles(): IWikiFile[] {
    const query = this.state.query.trim().toLowerCase();
    return query
      ? this.state.files.filter(file => file.Name.toLowerCase().indexOf(query) !== -1)
      : this.state.files;
  }

  private iconFor(name: string): string {
    const extension = (name.split('.').pop() || '').toLowerCase();
    if (extension === 'pdf') return 'PDF';
    if (['doc', 'docx', 'odt'].indexOf(extension) !== -1) return 'DOC';
    if (['xls', 'xlsx', 'csv', 'ods'].indexOf(extension) !== -1) return 'XLS';
    if (['ppt', 'pptx', 'odp'].indexOf(extension) !== -1) return 'PPT';
    return 'FILE';
  }

  public render(): React.ReactElement<IKaptureWikiProps> {
    const files = this.filteredFiles;
    return (
      <div className={styles.kaptureWiki}>
        <header className={styles.header}>
          <div className={styles.brand}>
            <img className={styles.logoImage} src={INDOVANCE_LOGO} alt="Indovance" />
            <div>
              <div className={styles.brandName}>Kapture Wiki</div>
              <div className={styles.brandSub}>INDOVANCE KNOWLEDGE HUB</div>
            </div>
          </div>
          <div className={styles.user}>Signed in as <strong>{this.props.displayName}</strong></div>
        </header>

        <section className={styles.hero}>
          <div className={styles.eyebrow}>KNOWLEDGE, CONNECTED</div>
          <h1>Your knowledge.<br /><span>One place.</span></h1>
          <p>Find the documents and information you need across Kapture.</p>
          <div className={styles.search}>
            <span aria-hidden="true">⌕</span>
            <input
              aria-label="Search documents"
              placeholder="Search documents by name..."
              value={this.state.query}
              onChange={event => this.setState({ query: event.currentTarget.value })}
            />
            <button type="button" onClick={() => this.setState({ query: '' })}>Clear</button>
          </div>
        </section>

        <main className={styles.content}>
          <div className={styles.sectionHeading}>
            <div>
              <div className={styles.eyebrow}>SHAREPOINT LIBRARY</div>
              <h2>Documents</h2>
            </div>
            <div className={styles.actions}>
              <button
                type="button"
                className={styles.upload}
                disabled={this.state.uploading}
                onClick={() => this.fileInput.current && this.fileInput.current.click()}
              >
                {this.state.uploading ? 'Uploading…' : '+ Upload document'}
              </button>
              <button type="button" className={styles.refresh} onClick={() => this.loadFiles()}>↻ Refresh</button>
              <input
                ref={this.fileInput}
                className={styles.fileInput}
                type="file"
                onChange={event => this.uploadFile(event.currentTarget.files && event.currentTarget.files.length ? event.currentTarget.files[0] : undefined)}
              />
            </div>
          </div>

          {!!this.state.uploadMessage && <div className={styles.uploadMessage} role="status">{this.state.uploadMessage}</div>}
          {this.state.loading && <div className={styles.status}>Loading files from SharePoint…</div>}
          {!!this.state.error && (
            <div className={styles.error}>
              <strong>Couldn’t load documents.</strong><br />
              {this.state.error}<br />
              <small>Confirm that this page is running inside the Kapture SharePoint site and that you have access.</small>
            </div>
          )}

          {!this.state.loading && !this.state.error && (
            <React.Fragment>
              <div className={styles.resultCount}>
                {files.length} document{files.length === 1 ? '' : 's'} {this.state.query ? 'found' : 'available'}
              </div>
              {files.length ? (
                <div className={styles.fileGrid}>
                  {files.map(file => (
                    <a
                      className={styles.fileCard}
                      href={`${new URL(this.props.siteUrl).origin}${file.ServerRelativeUrl}`}
                      target="_blank"
                      rel="noreferrer"
                      key={file.ServerRelativeUrl}
                    >
                      <div className={styles.fileIcon}>{this.iconFor(file.Name)}</div>
                      <div className={styles.fileInfo}>
                        <div className={styles.fileName}>{file.Name}</div>
                        <div className={styles.fileMeta}>
                          {file.Length ? `${Math.max(1, Math.round(Number(file.Length) / 1024))} KB` : 'SharePoint document'}
                          {' · '}{new Date(file.TimeLastModified).toLocaleDateString()}
                        </div>
                      </div>
                      <div className={styles.open}>↗</div>
                    </a>
                  ))}
                </div>
              ) : (
                <div className={styles.empty}>No matching documents. Try another search term.</div>
              )}
            </React.Fragment>
          )}
        </main>

        <footer className={styles.footer}>Kapture Wiki · Documents remain stored in SharePoint</footer>
      </div>
    );
  }
}
