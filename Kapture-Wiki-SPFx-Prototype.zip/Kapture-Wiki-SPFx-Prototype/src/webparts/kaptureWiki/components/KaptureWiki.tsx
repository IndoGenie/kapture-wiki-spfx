import * as React from 'react';
import * as mammoth from 'mammoth';
import * as XLSX from 'xlsx';
import * as JSZip from 'jszip';
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf';
import { createWorker } from 'tesseract.js';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IKaptureWikiProps, IWikiFile } from './IKaptureWikiProps';
import styles from './KaptureWiki.module.scss';
const INDOVANCE_LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYCAYAAAC+ZpjcAAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4nO3dzXXcWLIg4HhjAR3IMykLJrHCslMWPJYFTVlQlAWkLCjJArEtaI0FYi9zBT4LmOfAAXows8BVlapKP2QmgHtx8X3n1OnuBaXobgIIxA1ERAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMD6/FfuAIC8+qa9iIhd7jgq87DpDk+5gwDykWDBSvRNu40hkdpFxD8iYpv+YTrH9M9/IuIhhsTrmDEeYCYSLKhY37SXEfHfEbEPyVQpjhFxHxH/d9MdPuUNBZiKBAsq0zftPiL+GRGXEXGRNxp+4ikiPkXEvzbd4T5zLMCIJFhQgdRHdRkRN6FStVTHiHgXEZ/0b8HySbBgwVJidR0Rv4ZqVS2eIuJDRLyXaMFySbBgofqmvQoVq5o9RcTbTXe4yx0I8HISLFiYvml3EfFbDI3r1O8+hkTrIXcgwPP9r9wBAM/XN+1tRHQhuVqTfUR06f97YCFUsGAB0gyrjyGxWruHiPjFLC0onwQLCpfGLvw7NLEzeIohybrPHQjwfY4IoWCpkf1zSK74w0VEfE6/G0ChJFhQqNRz8zF3HBTro74sKJcjQihQ37QfI+Iqdxwswt2mO7zJHQTwZxIsKIzkihNIsqAwjgihIKmv5ipzGCzPlZ4sKIsKFhSib9rLGL4WhFO9MfkdyiDBggKk6ey+FuRcTxHx2tR3yE+CBZmlhc2fI2KXOxaqcIyIxqJoyEsPFuT3W0iuGM82ht8pICMVLMhI3xUT+mXTHT7lDgLWSoIFmaSjwcfQd8U0niLilaNCyMMRIeRzE5IrpnMRw+8YkIEKFmSQvhrscsfBKjS+KoT5qWBBHpqQmYt9lpCBBAtm1jftdUTsc8fBauzS7xwwI0eEMCON7WSi4R1mpoIF8/otJFfM7yIcS8OsVLBgJn3T7mOY2A65vN50h/vcQcAaqGDBfFQQyE3DO8xEggUz6Jv2NqzDIb9t+l0EJuaIECbWN+02hplXeq8owVMMs7GOuQOBmqlgwfQ0tlMSDe8wAxUsmJDGdgpmGTRMSIIFE0kzr7qI2GYOBb7lGMNRodlYMAFHhDCd65BcUa5tDL+jwARUsGACqbH9MXcc8AyvNLzD+FSwYBrmDbEUfldhAhIsGFnftJdhmTPLse+b9ip3EFAbR4QwIsucWSjLoGFkKlgwrpuQXLE8FzH87gIjUcGCkfRNu4thLAMsVbPpDg+5g4AaqGDBeEzHZuk0vMNIJFgwgr5pr0NjO8u3S7/LwJkcEcKZNLZTGQ3vMAIVLDifZc7UxDJoGIEKFpzBMmcq9nrTHe5zBwFLpYIF5/GmT638bsMZJFhwor5pbyNilzsOmMgu/Y4DJ3BECCdIy5y70HtF3Z5imI11zB0ILI0KFpxGYztroOEdTqSCBS+ksZ0V0vAOLyTBghdIM6+6iNhmDgXmdIzhqNBsLHgmR4TwMtchuWJ9tjH87gPPpIIFz5Qa2x9zxwEZvdLwDs+jggXPZxEua+cagGeSYMEz9E17GZY5wz5dC8BPOCKEn7DMGf7EMmh4BhUs+LmbkFzBFxcxXBPAD6hgwQ/0TbuLYSwD8GfNpjs85A4CSqWCBT9mijV8m2sDfkCCBd/RN+11aGyH79mnawT4BkeE8A0a2+FZNLzDd6hgwbdZ5gw/Zxk0fIcKFvyFZc7wYpZBw1+oYMHfeSOHl3HNwF9IsOArqWl3lzsOWJhd37S3uYOAkjgihCQtc+5C7xWc4imG2VjH3IFACVSw4A8a2+F0Gt7hKypYEBrbYUQa3iFUsOCLj7kDgEp8THPkYNUkWKxeas7dZg4DarGNCBPeWT1HhKxaamx/zB0HVOiVhnfWTAWLtXM0CNNwbbFqEixWq2/ay7DMGaayT9cYrJIjQlYpNeF2ofcKpmQZNKulgsVa3YTkCqZ2EcO1BqujgsXq9E27i6F6Bcyj2XSHh9xBwJxUsFgj06ZhXq45VkeCxar0TXsVGtthbvu0SB1WwxEhq5Ea2x/DvkHIQcM7q6KCxZpY5gz5WAbNqqhgsQqWOUMxLINmFVSwWAtvzlAG1yKrIMGieqm5dpc7DiAiInZpwTpUzREhVUvLnLvQewUleYphNtYxdyAwFRUsaqexHcqj4Z3qqWBRLY3tUDwN71RLBYuafcwdAPBDH9N8OqiOBIsqpSbabeYwgB/bRoQJ71TJESHVSY3tj7njAJ7tlYZ3aqOCRY0cDcKyuGapjgSLqvRNexmWOcPS7NO1C9VwREg1UrNsF3qvYImOMczGsgyaKqhgUZObkFzBUm1juIahCipYVKFv2l0M1Stg2ZpNd3jIHQScSwWLWpgKDXVwLVMFCRaL1zftVWhsh1rs0zUNi+aIkEVLje2PYd8g1OQphtlYGt5ZLBUsls4yZ6iPZdAsngoWi2WZM1TPMmgWSwWLJfOGC3VzjbNYEiwWqW/a64jY5Y4DmNQuXeuwOI4IWZy0zLkLvVewBk8xzMY65g4EXkIFiyXS2A7roeGdRVLBYlE0tsNqaXhnUVSwWJqPuQMAsnDtsygSLBajb9rbsMwZ1mqb7gGwCI4IWYTU2P6YOw4gu1ca3lkCFSyWwvEAEOFewEJIsChe37SXYZkzMNinewIUzREhRUvLnLvQewX84RjDbCzLoCmWChaluwnJFfBn2xjuDVAsFSyK1TftLobqFcC3NJvu8JA7CPgWFSxKZnoz8CPuERRLgkWR+qa9Co3twI/t070CiuOIkOKkxvbHsG8Q+LmnGGZjaXinKCpYlOgmJFfA81gGTZFUsCiKZc7AiSyDpigqWJTGmyhwCvcOiiLBohh9015HxC53HMAi7dI9BIrgiJAiaGwHRvAUw2ysY+5AQAWLUnwMyRVwHg3vFEMFi+w0tgMj0/BOdipYlOBj7gCAqrinkJ0Ei6z6pr0Ny5yBcW3TvQWycURINn3TbmNY5qz3CpjCKw3v5KKCRU4a24EpOSokGwkWWfRNexmWOQPT2qd7DczOESGzSzOvutB7BUzvGMNsLMugmZUKFjlch+QKmMc2hgXyMCsVLGbVN+0uhuoVwJyaTXd4yB0E66GCxdxMWQZycO9hVhIsZtM37VVobAfy2Kd7EMzCESGzsMwZKMBTDLOxNLwzORUs5nITkisgL8ugmY0KFpOzzBkojGXQTE4Fizl4YwRK4p7E5CRYTKpv2uuI2OWOA+Aru3Rvgsk4ImQyGtuBgml4Z1IqWEzJMmegVBdhGTQTUsFiEhrbgYXQ8M4kVLCYijdDYAncq5iEBIvR9U17G5Y5A8uwTfcsGJUjQkbVN+02hmXOeq+ApXiKYRn0MXcg1EMFi7FpbAeWRsM7o5NgMZq+aS/DMmdgmfbpHgajcETIKNLMqy70XgHLdYzhqNBsLM6mgsVYrkNyBSzbNoZ7GZxNBYuz9U27i6F6BVCDZtMdHnIHwbKpYDEGi1OBmrincTYJFmfpm/YqNLYDddmnexuczBEhJ7PMGaiYZdCcRQWLc9yE5Aqo00UM9zg4iQoWJ7HMGVgJy6A5iQoWp9IECqyBex0nkWDxYn3TXkfELnccADPYpXsevIgjQl5EYzuwQhreeTEVLF7KMmdgbSyD5sVUsHg2je3Ayml459lUsHgJb3DAmrkH8mwSLJ6lb9rbsMwZWLdtuhfCTzki5Kf6pt3GsMxZ7xWwdk8xLIM+5g6Esqlg8Rwa2wEGGt55FgkWP9Q37WVY5gzwtX26N8J3OSLku9LMqy70XgH81TGGo0KzsfgmFSx+5DokVwDfso3hHgnfpILFN6XG9sfccQAUrtl0h4fcQVAeFSy+RxMnwM9ZBs03SbD4m75pr0JjO8Bz7NM9E/7EESF/YpkzwItZBs3fqGDxVzchuQJ4iYsY7p3wOxUsftc37S6GsQwAvJxl0PxOBYuvaWwHOJ2Gd34nwSIiIvqmvY6IXe44ABZsl+6l4IgQje0AI9LwTkSoYDH4LSRXAGOwDJqIUMFavb5p9xHxOXccAJXR8L5yKlh40wIYn3vrykmwVqxv2tuwzBlgCtt0j2WlHBGuVFrm3IXeK4CpPMWwDPqYOxDmp4K1XhrbAaal4X3FJFgr1DftZURc5o4DYAX26Z7LyjgiXJk086oLvVcAcznGcFRoNtaKqGCtz3VIrgDmtI3h3suKqGCtSGpsf8wdB8BKvdLwvh4qWOui2RIgH/fgFZFgrUTftFcRsc8cBsCa7dO9mBVwRLgCljkDFMMy6JVQwVqHm5BcAZTgIoZ7MpVTwapc37S7GMYyAFCOZtMdHnIHwXRUsOqnqRKgPO7NlZNgVaxv2uuI2OWOA4C/2aV7NJVyRFgpje0AxdPwXjEVrHpZ5gxQtosY7tVUSAWrQn3T7iPic+44AHiW15vucJ87CMalglUnzZMAy+GeXSEJVmX6pr0Ny5wBlmSb7t1UxBFhRdIy5y70XgEszVMMs7GOuQNhHCpYddHYDrBMGt4rI8GqRN+0lxFxmTsOAE52me7lVMARYQXSzKsu9F4BLN0xhqNCs7EWTgWrDtchuQKowTaGezoLp4K1cKmx/TF3HACM6pWG92VTwVo+81MA6uPevnASrAXrm/YqIvaZwwBgfPt0j2ehHBEulGXOANWzDHrBVLCW6yYkVwA1u4jhXs8CqWAtUN+0uxjGMgBQv2bTHR5yB8HLqGAtk+ZHgPVwz18gCdbC9E17HRG73HEAMJtduvezII4IF0RjO8BqaXhfGBWsZbHMGWCdLINeGBWsheibdh8Rn3PHAUBWrzfd4T53EPycCtZyaHIEwLNgISRYC9A37W1Y5gxAxDY9EyicI8LCpWXOXei9AmDwFMNsrGPuQPg+FazyaWwH4Gsa3hdABatgGtsB+IFfNt3hU+4g+DYJVqHSzKsu9F4B8G3HGI4KzcYqkCPCcl2H5AqA79vG8KygQCpYBUqN7Y+54wBgEV5peC+PClaZzDkB4Lk8MwokwSpM37SXEbHPHQcAi7Hvm/YqdxD8mSPCgljmDMCJLIMujApWWW5CcgXAy13E8AyhECpYheibdhfDWAYAOFWz6Q4PuYNABaskpvICcC4N74WQYBWgb9rr0NgOwPl26ZlCZo4IM9PYDsDINLwXQAUrP8ucARiTZdAFUMHKyDJnACb0etMd7nMHsVYqWHl5wwBgKp4xGUmwMumb9jYidrnjAKBau/SsIQNHhBmkZc5d6L2Crx0j4iEi/if9+2NExPeOONJ1tE3/cR8R/zv95/1UAcICPcUwG+uYO5C1kWBl0DftvyPiMncckNkxIj5FxH8i4n7ML55Sf+M+Iv4REi74tOkOv+QOYm0kWDPT2M7KHSPiQww3/OMcf2EahXIZEf8dXmxYLw3vM5NgzSjd6Lv441gD1uIuIv6V+wafjhWvIuLXcETPuhxjOCo0G2smmtzndR2SK9blLoaBh29yJ1cREZvucNx0h9uIeBURbyL1ecEKbGN4BjETFayZpDfnx9xxwEzuIuLdEhpr01dWKlqsxaslXJc1UMGajwWcrMFDDL0eb5ZyE/+qonWXNxKYhWfRTFSwZtA37WVE/Dt3HDCxdylZWaz0EcrHcJRP3X7ZdIdPuYOonQRrYpY5swIPEfFm0x0ecgcyhnTNfgxfHFIvy6Bn4IhwejchuaJen2I4EqwiuYqI2HSHpzQz6G3uWGAiFzE8m5iQCtaE+qbdxTCWAWq0+CPBn0lHhv8OL0nUqanp5ag0KljTsmiTWr2pPbmK+H1Nz+sYjlSgNp5RE5JgTaRv2uuwooM6vdl0h7vcQcwlveFLsqjRPj2rmIAjwglobKdiq0quvpaO/D+H65q6aHifiArWNH4LN2Hqs9rkKkIli2pdhKPCSahgjcwyZyr1ftMdfFUXPl6hWpZBj0wFa3zeBKjNJ8nVH1Il603uOGBknl0jk2CNKO002+WOA0Z0DMnE36Sj0rvMYcCYdukZxkgkWCNJy5x/zR0HjOwXza/f9TaGKfZQi1/Ts4wRSLDGo7Gd2rwzhPD7UuKpukdNNLyPSJP7CDS2U6GHTXdocgexBOlYxdoRaqLhfQQqWGf6ajEs1ERT+/O9j6FXDWrxMT3bOIME63zXEbHNHQSM6M7b6/Olo0IJKTXZxvBs4wyOCM+QmgEfc8cBI3qKYQHsMXcgS9M37eewHou6vHIvOJ0K1nkcDVKbD26oJ1PFojaecWeQYJ2ob9rL8LZKXY4x9BNxgvTF5V3uOGBE+/Ss4wQSrBNobKdS78y8OtvbsKuQumh4P5EE6zQ3YeYVdblf8yLnsaQE9UPuOGBEF2EMyUk0ub+QRa9UytybEfVN+xi+LqYujcHDL6OC9XKm3FIbYxnGp+Gd2nj2vZAE6wX6pr0Oje3U5Ski3uUOojab7vApIu5zxwEj2qdnIM8kwXqm1OTnHJraGMswHXsKqc2Nhvfnk2A9n2XO1OYYxjJMJiWu/velJpZBv4AE6xnSMuerzGHA2IxlmN67MLaBulylZyI/IcF6Hhk7tTGWYQYpgdXjRm08E59BgvUTqalvlzsOGJmH/kw23eF9DMexUItd37S3uYMonQTrB9IyZ43t1MZYhvlpeKc2v6ZnJN8hwfoxje3UxpFVBimh/ZQ7DhiRhvefkGB9R2ris+SS2hjLkI/ho9TmUsP790mwvs8yZ2pzDGMDskmJreohtbEM+jskWN+Qmve2mcOAsRnLkN/7MLaBumwjwoT3b7Ds+S9S095j7jhgZPeb7vA6dxBE9E17FSrk1OeV9oM/U8H6Ozc+auRoqhBp/thD7jhgZJ6dfyHB+krftJdhmTP1MZahPBreqc0+PUNJJFhJatLzySm1MZahQCnhvcscBoztNw3vf5Bg/eEmNLZTH2MZymVPIbXZhuHcv5NgRUTftLvwFQT1OYaxDMVKie+H3HHAyK7TM3X1JFgDR4PUyFiG8tlTSI08U0OC9eWT6X3mMGBs9+lrNQqWEmA9ctRmn56tq7bqOVipGe8x7BukPq99ObgcfdN+Di961OUphtlYq62ir72CZZkzNTKWYXmMbaA2q/8yf7UJVlpQeZU5DBibI6cF2nSHhzC2gfpcrXkZ9GoTrFh5Zk21jGVYrrdhbAP1We2zdpUJVt+01xHhM1JqcwxjGRYr9aoY20BtdumZuzqra3JPy5y70HtFfd74cnD5+qZ9DEOPqctTRDRrq66vsYKlsZ0aGctQDw3v1GaVDe+rSrBSs51llNRIY3slNt3hU0Tc544DRna5tob3VSVYEfExdwAwAWMZ6vMmdwAwgVU9g1eTYPVNexv6GqiPsQwVSr0qPligNtv0LF6FVTS5p8b2x9xxwATebbrDbe4gGJ9NE1Ts1Roa3tdSwVpVWZLVOIYqR7XsKaRiq3gmV59g9U17GXZ8Uad3a97ztQab7vA+hkQaarJPz+aqVZ1gpRL76j4NZRWMZVgPDe/U6Lf0jK5W1QlWRNyExnbq5OhoJdIXop9yxwEj28bwjK5WtU3ufdPuYpjYDrW523QHVY0V8aEOFWvSsvPq1FzBcjRIjTQ+r1D64sr/79So2md1lQlW37RXobGdOn1Yw+fNfNP7GBJsqMk+PbOrU12CpbGdih3DWIbVSl+M2lNIjapseK8uwQrLnKmXsQwrl74crbJfhVWrsjBSVYKVFkleZQ4DpmAsA1+oYlGjq9qWQVeVYEWFGTAkHqpExO9jG+4yhwFTqOoZXk2C1TftdUTscscBE7ir9TNmTvYuNLxTn116llehigQrzYipemAZq6Wxmb9JX5J+yB0HTOAmPdMXr4oEKzS2U68PGtv5DnsKqVE1De+Ln+SemuI+544DJnDcdIdXuYOgXGl+0MfcccAEXqd+w8WqoYLl5kKtHA3yQ+nL0vvMYcAUFv9sX3SC1TftbVjmTJ3uN93Bgl+eQyJOjbbpGb9Yiz0itPyUylW7AJXx9U37McwApE6vlroebMkVrMWXD+E7jGXgpd6GsQ3UabHP+kUmWH3TXoZlztTJWAZeLH1pamwDNdqnZ/7iLO6IMC2E7ELvFXV6t+kOt7mDYJn6pn0M90bqc4yhbWJRVdolVrBuwg2EOh0lV5xJ9ZMabWOBw8QXlWD1TbuLiGrG6MNfeDhylvTl6X3uOGAC1ykHWIxFJVhRyXRX+AZjGRiLRJ1aLSoHWEyClSYW7zOHAVPxUGQU6QvU97njgAnsUy6wCItock+N7Y9h3yB1utt0hze5g6Ae7plU7CmG2VjFN7wvpYJlmTO1MpaB0aWHz7vcccAEFrMMuvgKlmXOVM5YBiZjbAMVK34Z9BIqWIvIVOEExjIwNUfP1Kr43KDoBKtv2uuIWNRnmfACjgaZVHrDv88cBkxhl3KEYhV7RKhJk8rdb7rD69xBUL++abcx3EuhNkU3vJdcwfoYkivqpXrFLDbd4Rga3qnTRRS8DLrIBCs1ti9yuSM8w12aVQRzeR/D2z7U5jLlDMUpMsGKgjNSOJOxDMwuHaH4vaNWReYMxSVYfdPehs+KqdeHUvsFqNumO9xFhMopNdqm3KEoRTW5p2bMLvReUafjpju8yh0E62WuIBV7iogm9RwWobQKlsZ2auaIhqzS2AZLxalRcQ3vxSRYfdNehmXO1Ot+0x082CjB29DwTp32KZcoQhEJVpp5VfxUVjiD6hVFSEcoH3LHARP5LeUU2RWRYEXEdWhsp17GMlCa9xFxzB0ETGAbQ06RXfYm975pdzE0tkONip40zHr1TXsVhfWswIia3C+2JVSwHA1SM2MZKFIa23CfOQyYSvbcImuCld6g9jljgAkdN93hNncQ8ANW6FCrfcoxssmWYGlsZwU0tlO0NLbhLnMYMJWsDe85K1g3YeYV9TKWgaUwtoFaXcSQa2SRJcFK04SL6PKHiahesQipR9DYBmp1nWsZdK4KlqNBamYsA4uSegWPmcOAqWTJOWZPsPqmvY6I3dx/L8zkKVSvWCa/t9Rql3KPWc06Bys1mz2G3ivq9c6XgyxV37Sfw5fd1Gn2mYRzV7Asc6ZmxjKwdKpY1Gr2ZdCzJVipyayYJYwwAQ8nFi31Dr7PHQdM5HLOhvc5K1hWMlAzYxmoxbswtoF6zZaLzJJg9U17G5Y5UzfVK6qQelRMeKdW25STTG7yJve+abcxLHPWe0Wt7jbd4U3uIGBMfdM+hhdj6vQUwzLo45R/yRwVLI3t1MxYBmrlpYFazdLwPmmC1TftZfjkl7p9mPOzX5hL2lN4nzkMmMo+5SiTmeyIMM286kKJmXodN93hVe4gYCqpxeMxdxwwkWMMR4WTvCRPWcG6DskVdXM0SNVSj4qGd2q1jQn3Ik9SweqbdhdD9Qpqdb/pDq9zBwFTs4GDFWim2B87VQXLMmdqp3rFKqTjE7/v1GySnGX0BKtv2qvQ2E7d7qZ424FSbbrDXUT4nadW+5S7jGrUBCuVklWvqJm3edbK7z01+y3lMKMZu4J1E87pqZuxDKxSGttgHRS1uoghhxnNaE3uPudlBYxlYNVs5mAFXo014X3MCtaomR8UyBEJq5YePB9yxwETGi2XGaWCpXrFChjLAGGINKswShVrrAqW6hW1U72C+H1sg+Gj1GyUnObsCpbqFStwt+kOFt/CV/qm/RxG8lCvs6tYY1Swrkb4M6BUxjLAt6liUbOrc/+AMRKsf47wZ0Cp3hnLAH+XxjbcZQ4DpnJ2bnNWgpV2Dm7PDQIKddx0h/e5g4CCvY2hygu12aYc52TnVrBUr6iZviv4gVTdNbaBWp2V45ybYF2e+fNQqvt0BAL8wKY73EbEMXMYMIWzcpyTE6z09eD2nL8cCqZ6Bc/nQxBqtE25zknOqWDtz/hZKNn7sVYlwBpsusOniLjPHQdMYH/qD56TYP3jjJ+FUhmiCKdRxaJGJ+c65yRYZ3XXQ6GMZYATbLrDQxjbQH22p/6gBAv+YCwDnMfYBmqzP/UHT0qwzmn6goJpbIcz2FNIjU7NeU6tYJ30l0HBjGWAEaQq8DF3HDCi7Sk/JMGCgeoVjMf1RE22p/yQBAuMZYBRpWrwfeYwYCzbU35ojGXPsGR6RmAaqlismgSLtTOWASaQqsK+ymW1JFismbEMMK13YWwDKyXBYs0cYcCEUnXYhHdWSYLFWhnLADPYdIe7iHjIHQfMTYLFWqlewXxUsVidUxMsZ+osmbEMMKNULf6UOw440Uk5z6kJlnIvS2UsA+ShisVSnZTzOCJkbYxlgAxS1djLDavxX6f+YN+0/2/MQGAGx013eJU7CFirvmkvIqIL20BYkE13OClXOqeCdTzjZyEHje2QUaoeq2KxJMdTf/CcBEsfFktiLAMUII1tuM8cBjzXybnOOQnW/5zxszA31SsohyoWS3FyrnNOgnV/xs/CnIxlgIKkavJd5jDgOe5P/cGTE6x0gfgai9Lp+YAy2VNI6Z7OaS05d0zDyX8xzMRYBihQqip/yB0H/MD9OT98boL1f8/8eZjScdMd3ucOAvi2TXe4DV+kU66zcpxzEyyrDyiZxnYonwnvlOqsHOesBCsdvdyd82fARIxlgAXYdIdPod2E8tyd214yxqqcf43wZ8DYVK9gOVSxKM3Zuc3ZCVaqEhzP/XNgRMYywIJsusNDOA2hHMcxTkDGWvbsM3hKYSwDLNPbMLaBMozyDBklwUqrD45j/FlwJmMZYIHsKaQQx5TTnG2sClaEC4P8jGWABUvX7zF3HKzaaLnMaAmWKhYF0NgOy+c6JpfRqlcR41awInwJQj7GMp04PVIAAAPQSURBVEAF0nV8nzkM1mnUHGbUBCvNMzF8lLk9hbdeqMmb0PDOvD6lHGY0Y1ewInwJwvzeGcsA9UjXs75e5vIUE5zAjZ5gpQvDUSFzudfYDvVJ1/V97jhYhbdTvKRPUcH60vB+N8WfDV9xNAh1c1TI1O7GbGz/2iQJVvI2Ih4m/PPhF0eDUK90ff+SOw6q9RATnrhNlmCloXHePpjKW18NQv3Sda7thLE9RcSbKQdT/9dUf/AXfdPuIuJzRFxM/XexGneb7uBoEFakb9qPEXGVOw6q8BQRr9MOzMlMeUQYEb8v8fT2wVgkV7BC6bq/yx0HVXg7dXIVMUMF64u+aa8i4uNcfx9VklzByqlkcaY3UzW1/9VsCVaEJIuzSK6AiJBkcbLZkquImROsCD1ZnOTdpjvc5g4CKEfftLcRcZM7DhZhlp6rv5q8B+uv0n/B12GEAz/35SuP29yBAGVJ9wVfqvMzD5EhuYrIUMH6om/aixiOCy9zxUDRHmJIriTiwHelU5GPEbHLHQvF+RQTj2L4kWwJ1hepL+u3cGTIH97HcCzozRT4qfTCfhMR17ljoQhPMXwpeJcziOwJVkRE37TbGN5A9nkjIbNjDG8b95njABaob9p9DM+Sbd5IyOhTTLRb8KWKSLC+6Jv2MoZq1jZzKMzrKSI+6LUCxpAa4H8NJyNrcowhsfqUO5AvikqwvkjHhjch0ardU0R8iIj3jgOBMaVjw+uQaNXuGENLyV3mOP6myATri5Ro/RqaF2tzjIh/hcQKmNhXidY/w0t7TR5iOPm4yx3I9xSdYH2RvhL5NYYvDr2JLNeniPhXSSVcYD1SG8o/w9frS/UUw3PkwxK+MF9EgvW1dIH8I4YLZJs3Gn7iy8Xwn4j4pFoFlCBVtb5+lnhxL9cx0nNkaS/ni0uwvpa+Ptylf/4Rw0XiODGPY/rnISL+JyLuS/iKA+Bn0inJLiL+T/rXbXiBz+Ehhhfz/6R//7Dk58iiE6wfSZ/rMr3jki8AgO9JL/HbzGFUz2geAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAqMf/B0KETNxABDi8AAAAAElFTkSuQmCC';
interface IKaptureWikiState { files: IWikiFile[]; query: string; loading: boolean; error: string; suggestionsOpen: boolean; page: number; selectedFile: IWikiFile | null; articleLoading: boolean; articleContent: string; articleHtml: string; articleError: string; }
const PAGE_SIZE = 8;
export default class KaptureWiki extends React.Component<IKaptureWikiProps, IKaptureWikiState> {
  private searchInput: React.RefObject<HTMLInputElement>;
  public constructor(props: IKaptureWikiProps) { super(props); this.state = { files: [], query: '', loading: true, error: '', suggestionsOpen: false, page: 1, selectedFile: null, articleLoading: false, articleContent: '', articleHtml: '', articleError: '' }; this.searchInput = React.createRef<HTMLInputElement>(); }
  public componentDidMount(): void { this.loadFiles(); }
  private async loadFiles(): Promise<void> {
    this.setState({ loading: true, error: '' });
    try {
      const folder = this.props.folderServerRelativeUrl.replace(/'/g, "''");
      const endpoint = `${this.props.siteUrl}/_api/web/GetFolderByServerRelativePath(decodedurl='${folder}')/Files?$select=Name,ServerRelativeUrl,TimeLastModified,Length&$orderby=TimeLastModified desc`;
      const response: SPHttpClientResponse = await this.props.spHttpClient.get(endpoint, SPHttpClient.configurations.v1, { headers: { Accept: 'application/json;odata=nometadata' } });
      if (!response.ok) { const detail = await response.text(); throw new Error(`SharePoint returned ${response.status}. ${detail.substring(0, 220)}`); }
      const data = await response.json(); this.setState({ files: (data.value || []) as IWikiFile[], loading: false });
    } catch (error) { this.setState({ loading: false, error: error instanceof Error ? error.message : 'An unexpected error occurred.' }); }
  }
  private fileType(name: string): string { const ext = (name.split('.').pop() || '').toLowerCase(); if (ext === 'pdf') return 'PDF'; if (['doc','docx','odt'].indexOf(ext) >= 0) return 'WORD'; if (['xls','xlsx','csv','ods'].indexOf(ext) >= 0) return 'EXCEL'; if (['ppt','pptx','odp'].indexOf(ext) >= 0) return 'SLIDES'; if (['mp4','mov','webm','avi'].indexOf(ext) >= 0) return 'VIDEO'; return 'FILE'; }
  private get filteredFiles(): IWikiFile[] { const q = this.state.query.trim().toLowerCase(); return this.state.files.filter(f => !q || f.Name.toLowerCase().indexOf(q) >= 0); }
  private selectFile(file: IWikiFile): void { this.setState({ selectedFile: file, suggestionsOpen: false, query: file.Name, articleLoading: true, articleContent: '', articleHtml: '', articleError: '' }, () => { this.loadArticleContent(file); }); }
  private async loadArticleContent(file: IWikiFile): Promise<void> {
    try {
      const escaped = file.ServerRelativeUrl.replace(/'/g, "''");
      const endpoint = `${this.props.siteUrl}/_api/web/GetFileByServerRelativePath(decodedurl='${escaped}')/$value`;
      const response = await this.props.spHttpClient.get(endpoint, SPHttpClient.configurations.v1, { headers: { Accept: 'application/octet-stream' } });
      if (!response.ok) throw new Error(`SharePoint could not provide the file content (${response.status}).`);
      const buffer = await response.arrayBuffer();
      const html = await this.extractDocumentHtml(file.Name, buffer);
      this.setState({ articleLoading: false, articleContent: html || '', articleHtml: html || '', articleError: html ? '' : 'No readable content was found. Scanned PDFs require OCR before they can be published as readable articles.' });
    } catch (e) { this.setState({ articleLoading: false, articleError: e instanceof Error ? e.message : 'Unable to read this document.' }); }
  }

  private escapeHtml(value: string): string {
    return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  private sanitizeArticleHtml(html: string): string {
    const parsed = new DOMParser().parseFromString(html, 'text/html');
    const allowed = ['P','H1','H2','H3','H4','H5','H6','UL','OL','LI','TABLE','THEAD','TBODY','TR','TH','TD','STRONG','B','EM','I','U','BLOCKQUOTE','BR','HR','A'];
    const clean = (node: Node): void => {
      Array.from(node.childNodes).forEach(child => {
        if (child.nodeType === 1) {
          const el = child as HTMLElement;
          clean(el);
          if (allowed.indexOf(el.tagName) < 0) {
            const parent = el.parentNode;
            if (parent) { while (el.firstChild) parent.insertBefore(el.firstChild, el); parent.removeChild(el); }
          } else {
            Array.from(el.attributes).forEach(a => el.removeAttribute(a.name));
            if (el.tagName === 'A') el.removeAttribute('href');
          }
        } else if (child.nodeType !== 3) child.parentNode && child.parentNode.removeChild(child);
      });
    };
    clean(parsed.body);
    return parsed.body.innerHTML;
  }
  private async extractDocumentHtml(name: string, buffer: ArrayBuffer): Promise<string> {
    const ext = (name.split('.').pop() || '').toLowerCase();
    if (ext === 'docx') {
      const result = await mammoth.convertToHtml({ arrayBuffer: buffer });
      return this.sanitizeArticleHtml(result.value);
    }
    if (ext === 'pdf') {
      const task: any = (pdfjsLib as any).getDocument({ data: new Uint8Array(buffer), disableWorker: true, useSystemFonts: true });
      const pdf: any = await task.promise;
      const pages: string[] = [];
      for (let pageNo = 1; pageNo <= pdf.numPages; pageNo++) {
        const page = await pdf.getPage(pageNo);
        const content = await page.getTextContent();
        const lines: string[] = [];
        let current = '';
        let previousY: number | null = null;
        (content.items || []).forEach((item: any) => {
          if (!item || typeof item.str !== 'string') return;
          const text = item.str.trim();
          if (!text) return;
          const y = item.transform && typeof item.transform[5] === 'number' ? item.transform[5] : null;
          if (current && y !== null && previousY !== null && Math.abs(y - previousY) > 2.5) { lines.push(current); current = ''; }
          current += (current ? ' ' : '') + text;
          if (y !== null) previousY = y;
        });
        if (current) lines.push(current);

        // Scanned/image-only PDF page: render it and run browser-side OCR.
        if (lines.join(' ').replace(/\s/g, '').length < 18) {
          let worker: any;
          try {
            const viewport = page.getViewport({ scale: 1.65 });
            const canvas = document.createElement('canvas');
            canvas.width = Math.ceil(viewport.width); canvas.height = Math.ceil(viewport.height);
            const context = canvas.getContext('2d');
            if (!context) throw new Error('Canvas is unavailable for PDF OCR.');
            await page.render({ canvasContext: context, viewport }).promise;
            worker = await createWorker('eng', 1, {
              workerPath: 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/worker.min.js',
              corePath: 'https://cdn.jsdelivr.net/npm/tesseract.js-core@5.1.1',
              langPath: 'https://tessdata.projectnaptha.com/4.0.0'
            });
            const result: any = await worker.recognize(canvas);
            const ocrText = result && result.data && result.data.text ? result.data.text : '';
            lines.splice(0, lines.length, ...ocrText.split(/\r?\n/).map((v: string) => v.trim()).filter(Boolean));
            canvas.width = 0; canvas.height = 0;
          } catch (ocrError) {
            throw new Error('This PDF appears to be scanned, and OCR could not run. Check that the browser can access the Tesseract OCR and English language-data CDN resources. ' + (ocrError instanceof Error ? ocrError.message : 'OCR failed.'));
          } finally {
            if (worker) await worker.terminate();
          }
        }

        const blocks = lines.map(line => {
          const trimmed = line.trim();
          if (/^(\d+(?:\.\d+)*[.)]?\s+.{3,}|[A-Z][A-Z0-9 &/()_-]{5,})$/.test(trimmed) && trimmed.length < 110) return `<h3>${this.escapeHtml(trimmed)}</h3>`;
          if (/^(?:[•▪◦‣–—-]|\d+[.)])\s+/.test(trimmed)) return `<li>${this.escapeHtml(trimmed.replace(/^(?:[•▪◦‣–—-]|\d+[.)])\s+/, ''))}</li>`;
          return `<p>${this.escapeHtml(trimmed)}</p>`;
        });
        const formatted: string[] = [];
        let listItems: string[] = [];
        blocks.forEach(block => {
          if (block.indexOf('<li>') === 0) listItems.push(block);
          else { if (listItems.length) { formatted.push(`<ul>${listItems.join('')}</ul>`); listItems = []; } formatted.push(block); }
        });
        if (listItems.length) formatted.push(`<ul>${listItems.join('')}</ul>`);
        if (formatted.length) pages.push(`<section class="wiki-page"><h2>Page ${pageNo}</h2>${formatted.join('')}</section>`);
      }
      return pages.join('');
    }
    if (['xlsx','xls'].indexOf(ext) >= 0) {
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
      return workbook.SheetNames.map((sheetName: string) => {
        const sheet = workbook.Sheets[sheetName];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: '' }) as any[][];
        if (!rows.length) return '';
        const head = rows[0];
        const body = rows.slice(1);
        return `<section class="wiki-sheet"><h2>${this.escapeHtml(sheetName)}</h2><div class="wiki-table-wrap"><table><thead><tr>${head.map(v => `<th>${this.escapeHtml(String(v))}</th>`).join('')}</tr></thead><tbody>${body.map(row => `<tr>${row.map((v: any) => `<td>${this.escapeHtml(String(v))}</td>`).join('')}</tr>`).join('')}</tbody></table></div></section>`;
      }).join('');
    }
    if (ext === 'csv') {
      const rows = new TextDecoder('utf-8').decode(buffer).split(/\r?\n/).filter(Boolean).map(line => line.split(','));
      return rows.length ? `<div class="wiki-table-wrap"><table><thead><tr>${rows[0].map(v => `<th>${this.escapeHtml(v)}</th>`).join('')}</tr></thead><tbody>${rows.slice(1).map(row => `<tr>${row.map(v => `<td>${this.escapeHtml(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : '';
    }
    if (ext === 'pptx') {
      // Preserve slide boundaries and paragraph breaks.
      return this.extractPptxHtml(buffer);
    }
    if (ext === 'txt') {
      return new TextDecoder('utf-8').decode(buffer).split(/\r?\n/).map(line => line.trim()).filter(Boolean).map(line => `<p>${this.escapeHtml(line)}</p>`).join('');
    }
    if (ext === 'odt' || ext === 'ods' || ext === 'odp') {
      const archive = await JSZip.loadAsync(buffer);
      const contentFile = archive.file('content.xml');
      if (!contentFile) throw new Error('The OpenDocument file does not contain readable content.xml data.');
      const xmlText = await contentFile.async('text');
      const xmlDoc = new DOMParser().parseFromString(xmlText, 'application/xml');
      const textOf = (node: Element): string => {
        const parts: string[] = [];
        Array.from(node.childNodes).forEach(child => {
          if (child.nodeType === 3) parts.push(child.textContent || '');
          else if (child.nodeType === 1) {
            const el = child as Element;
            if (el.localName === 's') parts.push(' ');
            else parts.push(textOf(el));
          }
        });
        return parts.join('').replace(/\\s+/g, ' ').trim();
      };
      if (ext === 'odt') {
        const blocks: string[] = [];
        Array.from(xmlDoc.getElementsByTagName('*')).filter(n => n.localName === 'h' || n.localName === 'p').forEach(n => {
          const value = textOf(n as Element);
          if (!value) return;
          const tag = n.localName === 'h' ? 'h2' : 'p';
          blocks.push(`<${tag}>${this.escapeHtml(value)}</${tag}>`);
        });
        Array.from(xmlDoc.getElementsByTagName('*')).filter(n => n.localName === 'table').forEach(table => {
          const rows = Array.from(table.getElementsByTagName('*')).filter(n => n.localName === 'table-row');
          const htmlRows = rows.map(row => {
            const cells = Array.from(row.children).filter(c => c.localName === 'table-cell' || c.localName === 'covered-table-cell');
            return `<tr>${cells.map(cell => `<td>${this.escapeHtml(textOf(cell))}</td>`).join('')}</tr>`;
          }).join('');
          if (htmlRows) blocks.push(`<div class="wiki-table-wrap"><table><tbody>${htmlRows}</tbody></table></div>`);
        });
        return blocks.join('');
      }
      if (ext === 'ods') {
        const tables = Array.from(xmlDoc.getElementsByTagName('*')).filter(n => n.localName === 'table');
        return tables.map(table => {
          const rows = Array.from(table.getElementsByTagName('*')).filter(n => n.localName === 'table-row');
          const cells = rows.map(row => Array.from(row.children).filter(c => c.localName === 'table-cell' || c.localName === 'covered-table-cell').map(c => textOf(c)));
          const heading = table.getAttribute('name') || 'Worksheet';
          return `<section class="wiki-sheet"><h2>${this.escapeHtml(heading)}</h2><div class="wiki-table-wrap"><table><tbody>${cells.map((row,i) => `<tr>${row.map(v => i === 0 ? `<th>${this.escapeHtml(v)}</th>` : `<td>${this.escapeHtml(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div></section>`;
        }).join('');
      }
      const pages = Array.from(xmlDoc.getElementsByTagName('*')).filter(n => n.localName === 'page');
      return pages.map((page,i) => {
        const paragraphs = Array.from(page.getElementsByTagName('*')).filter(n => n.localName === 'p' || n.localName === 'h');
        return `<section class="wiki-slide"><h2>Slide ${i+1}</h2>${paragraphs.map(p => `<p>${this.escapeHtml(textOf(p as Element))}</p>`).join('')}</section>`;
      }).join('');
    }
    if (ext === 'doc' || ext === 'ppt') {
      throw new Error('This older binary Office format must be converted to DOCX or PPTX before it can be displayed as a structured article.');
    }
    return '';
  }
  private async extractPptxHtml(buffer: ArrayBuffer): Promise<string> {
    // Reuse the ZIP central-directory reader, then preserve each slide as its own section.
    const bytes = new Uint8Array(buffer), view = new DataView(buffer), decoder = new TextDecoder('utf-8');
    let eocd = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65558); i--) { if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; } }
    if (eocd < 0) throw new Error('The PowerPoint file archive could not be read.');
    const count = view.getUint16(eocd + 10, true); let offset = view.getUint32(eocd + 16, true);
    const entries: { [key: string]: Uint8Array } = {};
    for (let i = 0; i < count; i++) {
      if (view.getUint32(offset, true) !== 0x02014b50) break;
      const method = view.getUint16(offset + 10, true), size = view.getUint32(offset + 20, true), nameLen = view.getUint16(offset + 28, true), extraLen = view.getUint16(offset + 30, true), commentLen = view.getUint16(offset + 32, true), local = view.getUint32(offset + 42, true);
      const entryName = decoder.decode(bytes.slice(offset + 46, offset + 46 + nameLen));
      const localName = view.getUint16(local + 26, true), localExtra = view.getUint16(local + 28, true), start = local + 30 + localName + localExtra;
      const packed = bytes.slice(start, start + size);
      if (method === 0) entries[entryName] = packed;
      else if (method === 8) {
        const DS = (window as any).DecompressionStream;
        if (!DS) throw new Error('PowerPoint extraction requires a modern Microsoft Edge browser.');
        entries[entryName] = new Uint8Array(await new Response(new Blob([packed]).stream().pipeThrough(new DS('deflate-raw'))).arrayBuffer());
      }
      offset += 46 + nameLen + extraLen + commentLen;
    }
    const slideNames = Object.keys(entries).filter(k => /^ppt\/slides\/slide[0-9]+\.xml$/.test(k)).sort((a,b) => Number(a.match(/slide(\d+)/)![1])-Number(b.match(/slide(\d+)/)![1]));
    return slideNames.map((slide, index) => {
      const doc = new DOMParser().parseFromString(decoder.decode(entries[slide]), 'application/xml');
      const paragraphs = Array.from(doc.getElementsByTagName('*')).filter(n => n.localName === 'p');
      const content = paragraphs.map(p => {
        const runs = Array.from(p.getElementsByTagName('*')).filter(n => n.localName === 't').map(n => n.textContent || '').join('');
        return runs.trim() ? `<p>${this.escapeHtml(runs)}</p>` : '';
      }).join('');
      return `<section class="wiki-slide"><h2>Slide ${index + 1}</h2>${content}</section>`;
    }).join('');
  }
  private renderFile(file: IWikiFile, compact: boolean = false): React.ReactElement {
    const type = this.fileType(file.Name);
    return <button type="button" className={compact ? styles.resultRow : styles.resourceCard} onClick={() => this.selectFile(file)} key={file.ServerRelativeUrl}>
      <span className={`${styles.fileGlyph} ${type === 'VIDEO' ? styles.videoGlyph : ''}`}>{type === 'VIDEO' ? '▶' : type === 'PDF' ? 'PDF' : type === 'WORD' ? 'W' : type === 'EXCEL' ? 'X' : type === 'SLIDES' ? 'P' : '▤'}</span>
      <span className={styles.fileText}><strong>{file.Name}</strong><small>{type === 'VIDEO' ? 'Training video' : `${type} document`} <span>·</span> {new Date(file.TimeLastModified).toLocaleDateString()}</small></span><span className={styles.openArrow}>→</span>
    </button>;
  }
  private renderArticle(): React.ReactElement {
    const file = this.state.selectedFile as IWikiFile;
    const title = file.Name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ');
    return <div className={styles.articlePage}>
      <button className={styles.backButton} onClick={() => this.setState({ selectedFile: null, query: '', articleContent: '', articleHtml: '' })}>← Back to knowledge search</button>
      <div className={styles.articleLayout}><article className={styles.articleBody}>
        <div className={styles.articleEyebrow}>KAPTURE WIKI <span> / </span> KNOWLEDGE ARTICLE</div>
        <h1>{title}</h1>
        <div className={styles.articleMeta}>INDOVANCE KNOWLEDGE BASE <span>·</span> Updated {new Date(file.TimeLastModified).toLocaleDateString()}</div>
        {this.state.articleLoading && <div className={styles.articleCallout}><strong>Preparing knowledge article</strong><p>Reading and organising the source content…</p></div>}
        {!!this.state.articleError && <div className={styles.articleCallout}><strong>Content could not be fully extracted</strong><p>{this.state.articleError}</p></div>}
        {!this.state.articleLoading && !!this.state.articleHtml && <div className={styles.extractedArticle} dangerouslySetInnerHTML={{ __html: this.state.articleHtml }} />}
        {!this.state.articleLoading && !this.state.articleContent && !this.state.articleError && <div className={styles.articleCallout}><strong>No readable content found</strong><p>The source may contain scanned pages or unsupported content. OCR and richer document conversion are required for this file.</p></div>}
      </article><aside className={styles.articleAside}><span className={styles.asideKicker}>ARTICLE DETAILS</span><div className={styles.detailRow}><small>Last updated</small><strong>{new Date(file.TimeLastModified).toLocaleDateString()}</strong></div><div className={styles.detailRow}><small>Knowledge space</small><strong>Indovance</strong></div><p>Content is presented inside Kapture Wiki. The original repository file remains in SharePoint.</p></aside></div>
    </div>;
  }
  public render(): React.ReactElement<IKaptureWikiProps> {
    const filtered = this.filteredFiles; const suggestions = this.state.query.trim() ? filtered.slice(0,5) : []; const totalPages = Math.max(1, Math.ceil(filtered.length/PAGE_SIZE)); const visible = filtered.slice((this.state.page-1)*PAGE_SIZE,this.state.page*PAGE_SIZE); const videos = this.state.files.filter(f => this.fileType(f.Name)==='VIDEO');
    if (this.state.selectedFile) return <div className={styles.kaptureWiki}><header className={styles.topbar}><div className={styles.brandBlock}><img src={INDOVANCE_LOGO} alt="Indovance" className={styles.logo}/><span className={styles.brandDivider}/><div><strong>Kapture Wiki</strong><small>KNOWLEDGE THAT MOVES US FORWARD</small></div></div><div className={styles.topbarRight}><span className={styles.statusDot}/><span>Indovance Knowledge Hub</span><div className={styles.avatar}>{(this.props.displayName || 'I').charAt(0).toUpperCase()}</div></div></header>{this.renderArticle()}<footer className={styles.footer}><span>© Indovance · Kapture Wiki</span><span>One organisation. One knowledge space.</span></footer></div>;
    return <div className={styles.kaptureWiki}>
      <header className={styles.topbar}><div className={styles.brandBlock}><img src={INDOVANCE_LOGO} alt="Indovance" className={styles.logo}/><span className={styles.brandDivider}/><div><strong>Kapture Wiki</strong><small>KNOWLEDGE THAT MOVES US FORWARD</small></div></div><div className={styles.topbarRight}><span className={styles.statusDot}/><span>Indovance Knowledge Hub</span><div className={styles.avatar}>{(this.props.displayName || 'I').charAt(0).toUpperCase()}</div></div></header>
      <section className={styles.hero}><div className={styles.heroInner}><div className={styles.heroEyebrow}><span/> THE KNOWLEDGE OF INDOVANCE</div><h1>Knowledge, made<br/><em>easy to discover.</em></h1><p>Search Indovance policies, processes, SOPs, technical knowledge and learning resources.</p>
        <div className={styles.searchWrap}><div className={styles.searchBox}><span className={styles.searchIcon}>⌕</span><input ref={this.searchInput} value={this.state.query} placeholder="Search policies, SOPs, checklists, training and more..." aria-label="Search Indovance knowledge" onFocus={()=>this.setState({suggestionsOpen:true})} onChange={e=>this.setState({query:e.currentTarget.value,suggestionsOpen:true,page:1})} onKeyDown={e=>{if(e.key==='Enter'||e.key==='Escape')this.setState({suggestionsOpen:false});}}/>{!!this.state.query && <button className={styles.clearSearch} onClick={()=>this.setState({query:'',suggestionsOpen:false,page:1})}>×</button>}<span className={styles.searchHint}>↵</span></div>
        {this.state.suggestionsOpen && suggestions.length>0 && <div className={styles.suggestions}><div className={styles.suggestionLabel}>SUGGESTED RESOURCES</div>{suggestions.map(f=><button key={f.ServerRelativeUrl} onMouseDown={e=>e.preventDefault()} onClick={()=>this.selectFile(f)}><span className={styles.suggestionIcon}>{this.fileType(f.Name)==='VIDEO'?'▶':'▤'}</span><span>{f.Name}</span><span className={styles.suggestionArrow}>↗</span></button>)}<div className={styles.suggestionFooter}>{filtered.length} matching resources</div></div>}</div>
        <div className={styles.searchNote}>✦ &nbsp;One search across Indovance knowledge</div></div><div className={styles.heroArt}><div className={styles.artRing}/><div className={styles.artRingTwo}/><div className={styles.artCore}>i</div><span className={styles.artDot}/></div></section>
      <main className={styles.mainContent}><section className={styles.welcomeStrip}><div><span className={styles.welcomeLabel}>WELCOME TO YOUR KNOWLEDGE SPACE</span><h2>{this.props.displayName ? this.props.displayName.split(' ')[0] : 'Hello'}, what are you looking for today?</h2></div><div className={styles.welcomeMeta}><span/> ONE INDOVANCE. SHARED KNOWLEDGE.</div></section>
      <section className={styles.resourcesSection}><div className={styles.sectionTitle}><div><span className={styles.sectionKicker}>YOUR KNOWLEDGE LIBRARY</span><h3>{this.state.query?'Search results':'Recently added resources'}</h3><p>{this.state.query?`Showing matches for “${this.state.query}”`:'Search and open knowledge resources from across Indovance.'}</p></div><button className={styles.refreshButton} onClick={()=>this.loadFiles()}>↻ Refresh</button></div>
      {this.state.loading&&<div className={styles.loadingState}><span className={styles.spinner}/> Loading your knowledge library…</div>}{!!this.state.error&&<div className={styles.errorState}><strong>We couldn’t load the resources.</strong><span>{this.state.error}</span></div>}
      {!this.state.loading&&!this.state.error&&<>{visible.length?<div className={styles.resourceGrid}>{visible.map(f=>this.renderFile(f))}</div>:<div className={styles.emptyState}><span>⌕</span><strong>No matching resources yet</strong><p>Try another keyword or a different search phrase.</p></div>}{filtered.length>PAGE_SIZE&&<div className={styles.pagination}><span>Showing {(this.state.page-1)*PAGE_SIZE+1}–{Math.min(this.state.page*PAGE_SIZE,filtered.length)} of {filtered.length}</span><div><button disabled={this.state.page<=1} onClick={()=>this.setState({page:this.state.page-1})}>←</button><span>Page {this.state.page} of {totalPages}</span><button disabled={this.state.page>=totalPages} onClick={()=>this.setState({page:this.state.page+1})}>→</button></div></div>}</>}</section>
      {videos.length>0&&<section className={styles.videoSection}><div className={styles.sectionTitle}><div><span className={styles.sectionKicker}>WATCH & LEARN</span><h3>Learning on demand</h3><p>Training videos and knowledge sessions from your colleagues.</p></div></div><div className={styles.videoList}>{videos.slice(0,4).map(f=>this.renderFile(f,true))}</div></section>}
      <div className={styles.bottomInsight}><span>✦</span><div><strong>Knowledge grows when it’s shared.</strong><p>A shared space for the knowledge, experience and expertise of Indovance.</p></div><b>INDOVANCE</b></div></main>
      <footer className={styles.footer}><span>© Indovance · Kapture Wiki</span><span>One organisation. One knowledge space.</span></footer>
    </div>;
  }
}
