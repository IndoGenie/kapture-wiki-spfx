      this.setState({ uploadMessage: 'Please choose a file smaller than 10 MB.' });
      if (this.fileInput.current) this.fileInput.current.value = '';
      return;
    }
    this.setState({ uploading: true, uploadMessage: `Uploading ${file.name}…` });
    try {
      const folder = this.props.folderServerRelativeUrl.replace(/'/g, "''");
      const fileName = file.name.replace(/'/g, "''");
      const endpoint = `${this.props.siteUrl}/_api/web/GetFolderByServerRelativePath(decodedurl='${folder}')/Files/AddUsingPath(decodedurl='${encodeURIComponent(fileName)}',overwrite=true)`;
      const buffer = await file.arrayBuffer();
      const response: SPHttpClientResponse = await this.props.spHttpClient.post(endpoint, SPHttpClient.configurations.v1, {
        headers: { 'Accept': 'application/json;odata=nometadata', 'Content-Type': 'application/octet-stream' },
        body: buffer as unknown as string
      });
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`SharePoint upload failed (${response.status}). ${detail.substring(0, 220)}`);
      }
      this.setState({ uploading: false, uploadMessage: `${file.name} uploaded successfully.` });
      await this.loadFiles();
    } catch (e) {
      this.setState({ uploading: false, uploadMessage: e && e.message ? e.message : 'Upload failed. Check that you have permission to add files to this SharePoint folder.' });
    } finally {
      if (this.fileInput.current) this.fileInput.current.value = '';
    }
  }
  private get filteredFiles(): IWikiFile[] {
    const q = this.state.query.trim().toLowerCase();
    return q ? this.state.files.filter(f => f.Name.toLowerCase().indexOf(q) >= 0) : this.state.files;
  }
  private iconFor(name: string): string {
    const ext = (name.split('.').pop() || '').toLowerCase();
    if (ext === 'pdf') return 'PDF'; if (['doc','docx','odt'].indexOf(ext) >= 0) return 'DOC';
    if (['xls','xlsx','csv','ods'].indexOf(ext) >= 0) return 'XLS'; if (['ppt','pptx','odp'].indexOf(ext) >= 0) return 'PPT'; return 'FILE';
  }
  public render(): React.ReactElement<IKaptureWikiProps> {
    return <div className={styles.kaptureWiki}>
      <header className={styles.header}>
        <div className={styles.brand}><img className={styles.logoImage} src={INDOVANCE_LOGO} alt="Indovance"/><div><div className={styles.brandName}>Kapture Wiki</div><div className={styles.brandSub}>INDOVANCE KNOWLEDGE HUB</div></div></div>
        <div className={styles.user}>Signed in as <strong>{this.props.displayName}</strong></div>
      </header>
      <section className={styles.hero}>
        <div className={styles.eyebrow}>KNOWLEDGE, CONNECTED</div>
        <h1>Your knowledge.<br/><span>One place.</span></h1>
        <p>Find the documents and information you need across Kapture.</p>
        <div className={styles.search}><span>⌕</span><input aria-label="Search documents" placeholder="Search documents by name..." value={this.state.query} onChange={e => this.setState({ query: e.currentTarget.value })}/><button onClick={() => this.setState({ query: '' })}>Clear</button></div>
      </section>
      <main className={styles.content}>
        <div className={styles.sectionHeading}><div><div className={styles.eyebrow}>SHAREPOINT LIBRARY</div><h2>Documents</h2></div><div className={styles.actions}><button className={styles.upload} disabled={this.state.uploading} onClick={() => this.fileInput.current && this.fileInput.current.click()}>{this.state.uploading ? 'Uploading…' : '+ Upload document'}</button><button className={styles.refresh} onClick={() => this.loadFiles()}>↻ Refresh</button><input ref={this.fileInput} className={styles.fileInput} type="file" onChange={e => this.uploadFile(e.currentTarget.files && e.currentTarget.files[0])}/></div></div>
        {!!this.state.uploadMessage && <div className={styles.uploadMessage} role="status">{this.state.uploadMessage}</div>}
        {this.state.loading && <div className={styles.status}>Loading files from SharePoint…</div>}
        {!!this.state.error && <div className={styles.error}><strong>Couldn't load documents.</strong><br/>{this.state.error}<br/><small>Confirm that this page is running inside the Kapture SharePoint site and that you have access.</small></div>}
        {!this.state.loading && !this.state.error && <>
          <div className={styles.resultCount}>{this.filteredFiles.length} document{this.filteredFiles.length === 1 ? '' : 's'} {this.state.query ? 'found' : 'available'}</div>
          {this.filteredFiles.length ? <div className={styles.fileGrid}>{this.filteredFiles.map(file => <a className={styles.fileCard} href={`https://teknovance.sharepoint.com${file.ServerRelativeUrl}`} target="_blank" rel="noreferrer" key={file.ServerRelativeUrl}><div className={styles.fileIcon}>{this.iconFor(file.Name)}</div><div className={styles.fileInfo}><div className={styles.fileName}>{file.Name}</div><div className={styles.fileMeta}>{file.Length ? `${Math.max(1, Math.round(Number(file.Length) / 1024))} KB` : 'SharePoint document'} · {new Date(file.TimeLastModified).toLocaleDateString()}</div></div><div className={styles.open}>↗</div></a>)}</div> : <div className={styles.empty}>No matching documents. Try another search term.</div>}
        </>}
      </main>
      <footer className={styles.footer}>Kapture Wiki · Documents remain stored in SharePoint</footer>
    </div>;
  }
}
