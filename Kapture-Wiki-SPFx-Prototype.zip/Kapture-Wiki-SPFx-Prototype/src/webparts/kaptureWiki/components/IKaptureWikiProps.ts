import { SPHttpClient } from '@microsoft/sp-http';
export interface IKaptureWikiProps { siteUrl: string; folderServerRelativeUrl: string; spHttpClient: SPHttpClient; displayName: string; }
export interface IWikiFile { Name: string; ServerRelativeUrl: string; TimeLastModified: string; Length: string; }
