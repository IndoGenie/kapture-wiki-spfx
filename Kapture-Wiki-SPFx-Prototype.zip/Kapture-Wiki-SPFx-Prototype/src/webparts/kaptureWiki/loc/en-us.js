define([], function () { return { "PropertyPaneDescription": "Kapture Wiki settings", "BasicGroupName": "Settings", "DescriptionFieldLabel": "Description" }; });
