# Kapture Wiki – Employee Portal UI (SPFx)

Version: 0.3.4.0 (development build)

This update redesigns the employee-facing Kapture Wiki experience while preserving the existing SPFx solution identity and the SharePoint Kapture Knowledge Repository connection.

## Included in this iteration

- Indovance-branded employee home page using the existing embedded logo.
- Updated visual system: dark hero, red/yellow brand accents, refined typography, responsive layouts and resource cards.
- Search box with live filename suggestions from the files currently returned by the configured SharePoint folder.
- Recently added resource listing, basic pagination, refresh and empty/error/loading states.
- Department overview cards based on the department structure discussed for Indovance.
- New-tab links to original SharePoint files; video file types are identified and surfaced in a Learning on Demand section.
- No upload button or administrative controls in this employee interface.
- Existing SharePoint site, web-part and solution IDs are retained. Solution version advanced to 0.1.4.0 for an update package.

## Current prototype boundaries

This is an employee-interface development iteration, not the completed production wiki.

- The data query now recursively enumerates the configured repository folder and its department/category subfolders. It reads supported file metadata from SharePoint and sorts results by last-modified date.
- Department cards are a visual navigation framework; folder-specific browsing will be connected when the department folders are created.
- Search currently matches filenames across the recursively loaded repository. It is not SharePoint full-text search and does not yet search document contents or metadata.
- The Learning on Demand section recognises common video extensions and links to the SharePoint-hosted file. Actual in-browser playback depends on SharePoint/browser support and file format; a dedicated player integration is a later validation item.
- Confidentiality trimming and role enforcement are not implemented by this UI change. They must be implemented and validated against SharePoint permissions before production use.
- This employee portal intentionally has no upload controls. Admin functionality will be developed as a separate role-aware experience after the employee interface is approved.
- Opening files in a new tab does not itself prevent downloads. Download restrictions must be configured and tested in SharePoint/Microsoft 365.

## Build

Upload this source archive to the repository root as `Kapture-Wiki-SPFx-Prototype.zip`. Use the repository's GitHub Actions workflow at `.github/workflows/build.yml` with Node.js 18.19.0. The workflow installs dependencies, runs the SPFx bundle and package tasks, verifies `sharepoint/solution/kapture-wiki.sppkg`, and publishes the package artifact.

Expected package:

`sharepoint/solution/kapture-wiki.sppkg`

Do not upload the source ZIP to SharePoint App Catalog. Only upload the generated `.sppkg` after a successful GitHub Actions build.


## Version 0.1.8.0 — structured article rendering
- DOCX content is converted to semantic HTML with headings, paragraphs, lists and tables using Mammoth.
- PDF text-layer extraction uses PDF.js and preserves page boundaries; scanned/image-only PDFs still require OCR.
- XLSX/XLS workbook sheets are rendered as readable tables.
- PPTX slides are separated into slide sections.
- ODT/ODS/ODP content is parsed from OpenDocument XML.
- CSV is rendered as a table.
- Article HTML is sanitised before rendering inside the portal.
- Legacy binary DOC/PPT files require conversion to modern Office formats.


## Release 0.1.8.4

- Fixed PDF.js runtime export resolution and set the version-matched PDF worker URL explicitly before opening a PDF.
- Added per-selection request sequencing so a slower extraction cannot replace the currently selected article.
- Added automatically generated in-article navigation from extracted H1/H2/H3 headings.
- Added article actions (print, copy link, open source) and an editorial reading layout.
- Preserved the existing SharePoint solution and web-part identities.

Note: scanned-PDF OCR still depends on browser access to the configured Tesseract worker/core/language resources. For production use in a locked-down tenant, host these resources internally or use an approved document-intelligence service.


## Release 0.2.0.0 — Knowledge experience refinement
- Replaced the externally hosted PDF.js worker dependency with a worker bundled into the SPFx solution.
- Preserved inline images embedded in DOCX content and added responsive article image styling.
- Made homepage topic tiles actionable as focused searches rather than decorative cards.
- Improved search suggestions with a scrollable dropdown and a clear no-results state.
- Filtered unsupported archive and miscellaneous file types from employee-facing knowledge results.
- Preserved the existing SharePoint folder source, solution ID, and web part ID.


## v0.3.0 changes
- Added an initial content administration view with upload to the configured SharePoint knowledge folder.
- Added a related-knowledge panel to article reading pages.
- Kept same SharePoint solution and web part IDs.
- Category and department selectors are currently workflow guidance only; they are not persisted as SharePoint metadata.
- Restrict access to the Admin entry/page through SharePoint page or site permissions before production use.


## Release 0.3.4.0 — repository integration
- Changed the default Employee Wiki source to `/sites/Kapture/Shared Documents/Kapture Knowledge Repository`.
- Added recursive discovery of supported documents in nested department, subdepartment and category folders, including SharePoint paginated collection responses.
- Preserved the existing solution ID and web-part ID.
- Search remains filename-based; this release does not claim full-text document-content or metadata search.
- Existing web-part instances that retain the old test-folder property will use the new repository default because the new repository property takes precedence and is now the configured default.
