# Kapture Wiki – Employee Portal UI (SPFx)

Version: 0.1.4 (development build)

This update redesigns the employee-facing Kapture Wiki experience while preserving the existing SPFx solution identity and the current SharePoint test-folder connection.

## Included in this iteration

- Indovance-branded employee home page using the existing embedded logo.
- Updated visual system: dark hero, red/yellow brand accents, refined typography, responsive layouts and resource cards.
- Search box with live filename suggestions from the files currently returned by the configured SharePoint folder.
- Recently added resource listing, basic pagination, refresh and empty/error/loading states.
- Department overview cards based on the department structure discussed for Indovance.
- New-tab links to original SharePoint files; video file types are identified and surfaced in a Learning on Demand section.
- No upload button or administrative controls in this employee interface.
- Existing SharePoint site, web-part and solution IDs are retained. Solution version advanced to 0.1.4.0 for an update package.

## Current prototype boundaries

This is an employee-interface development iteration, not the completed production wiki.

- The current data query still reads files from the configured test folder's root. It does not yet recursively enumerate future department/sub-department folders.
- Department cards are a visual navigation framework; folder-specific browsing will be connected when the department folders are created.
- Search currently matches filenames in the loaded folder. It is not SharePoint full-text search and does not yet search document contents or metadata.
- The Learning on Demand section recognises common video extensions and links to the SharePoint-hosted file. Actual in-browser playback depends on SharePoint/browser support and file format; a dedicated player integration is a later validation item.
- Confidentiality trimming and role enforcement are not implemented by this UI change. They must be implemented and validated against SharePoint permissions before production use.
- This employee portal intentionally has no upload controls. Admin functionality will be developed as a separate role-aware experience after the employee interface is approved.
- Opening files in a new tab does not itself prevent downloads. Download restrictions must be configured and tested in SharePoint/Microsoft 365.

## Build

Upload this source archive to the repository root as `Kapture-Wiki-SPFx-Prototype.zip`. Use the repository's GitHub Actions workflow at `.github/workflows/build.yml` with Node.js 18.19.0. The workflow installs dependencies, runs the SPFx bundle and package tasks, verifies `sharepoint/solution/kapture-wiki.sppkg`, and publishes the package artifact.

Expected package:

`sharepoint/solution/kapture-wiki.sppkg`

Do not upload the source ZIP to SharePoint App Catalog. Only upload the generated `.sppkg` after a successful GitHub Actions build.


## Version 0.1.8.0 — structured article rendering
- DOCX content is converted to semantic HTML with headings, paragraphs, lists and tables using Mammoth.
- PDF text-layer extraction uses PDF.js and preserves page boundaries; scanned/image-only PDFs still require OCR.
- XLSX/XLS workbook sheets are rendered as readable tables.
- PPTX slides are separated into slide sections.
- ODT/ODS/ODP content is parsed from OpenDocument XML.
- CSV is rendered as a table.
- Article HTML is sanitised before rendering inside the portal.
- Legacy binary DOC/PPT files require conversion to modern Office formats.


## Release 0.1.8.4 – document fidelity and build corrections

- Preserves the existing SharePoint solution ID and web-part ID.
- Adds per-selection request tracking so a slower extraction from a previously selected file cannot replace the currently selected article.
- Adds cache-busting/no-cache headers to SharePoint file-content requests to reduce stale document responses.
- Uses PDF.js no-worker mode to avoid the external PDF worker URL failure seen in SharePoint pages.
- Improves OpenDocument text/list/table rendering and CSV handling.
- Expands the search suggestion overlay and improves article reading typography.
- Uses the existing Tesseract.js browser OCR path for image-only PDF pages.

**OCR deployment note:** Browser OCR still depends on the user's browser being allowed to load the Tesseract worker, WASM core and language data from the configured public CDNs. This package does not include a server-side OCR service. For guaranteed enterprise OCR (especially when external CDNs are blocked), Indovance will need an approved Azure AI Document Intelligence endpoint or another internally hosted OCR service and its credentials/configuration. Do not treat an image-only PDF as successfully indexed until OCR text has been extracted and reviewed.

## Build

The repository workflow expects the source archive to be named `Kapture-Wiki-SPFx-Prototype.zip` in the repository root. Replace that file with this release archive and push to `main` (or run the workflow manually).
